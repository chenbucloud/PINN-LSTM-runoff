
from __future__ import annotations
import types as _t
import os, sys
import threading
import warnings
from dataclasses import dataclass, asdict
from typing import Any, Dict

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset

warnings.filterwarnings("ignore")
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "PingFang SC",
                                   "WenQuanYi Zen Hei", "Noto Sans CJK SC", "sans-serif"]
plt.rcParams["axes.unicode_minus"] = False


@dataclass
class Config:
    file_path: str = r"C:\Users\10792\PycharmProjects\PythonProject2\basin2_input_2013_2025.xlsx"
    sheet_name: str = "Sheet1"
    start_date: str = "2013-01-01"
    evap_valid_date: str = "2007-01-01"
    seq_len: int = 60
    pred_step: int = 7
    feat_dim: int = 9
    train_rate: float = 0.7      # 训练段比例
    val_rate: float = 0.2        # 验证段比例(用于选点); 测试段 = 1 - train - val
    # 网络
    hidden_dim: int = 64
    lstm_layers: int = 2
    dropout: float = 0.1
    # 物理
    rain_days: int = 8            # (1) 自由参数单位线长度（天）
    area_up: float = 738.5
    area_loc: float = 738.5
    storm_threshold: float = 30.0
    k1_init: float = 0.83
    cn_lo_init: float = 55.0      # (2) SCS-CN 曲线数下限（干期）
    cn_hi_init: float = 92.0      # (2) SCS-CN 曲线数上限（湿润期）
    alpha_run_init: float = 0.5   # (3) 产流量级修正 alpha 初值（诊断：原式偏大约 2.14 倍）
    gamma_run_init: float = 1.0   # (4) 产流曲率 gamma 初值（>1 压小放大，掰正中/洪峰偏差）
    uh_smooth_weight: float = 0.0# (5) 单位线平滑惩罚权重（抑制非物理双峰形状）
    calibrate_physics: bool = True  # (方案A) 训练前用观测率定物理参数
    freeze_physics: bool = True# (方案A) 率定后冻结 k1/alpha/gamma
    calib_gamma_max: float = 1.5    # (方案A) gamma 网格搜索上限
    calib_flow_weight_ref: float = 100000000# (方案A) 校准洪峰加权参考流量 (m3/s)
    print_samples: int = 5           # 训练前打印 n 条特征样本（0=关闭），便于核对数据
    print_samples_file: str = "feature_samples.txt"   # 样本明细输出文件（空=不保存）
    # 训练
    epochs: int = 100
    lr: float = 5e-4
    batch_size: int = 256
    grad_clip: float = 2.0
    physics_weight: float = 1.0# 【A/B 对照】物理权重置 0 = 纯 LSTM 基线
    # 物理损失流量门控：只在洪峰期强约束（低流量物理无信息，且会拖累 NSE_low）
    phys_q_gate: float = 0.0# 门控中心 (m3/s)
    phys_q_width: float = 120.0      # 门控过渡宽度
    phys_gate_floor: float = 1.0# 低流量权重 0（物理只作用于洪峰期）
    physics_warmup_epochs: int = 300
    weight_decay: float = 1e-5
    early_stop_patience: int = 500
    low_flow_threshold_norm: float = 0.15
    low_flow_weight: float = 5.0
    huber_delta: float = 0.1
    peak_recall_weight: float = 15.0
    peak_recall_quantile: float = 0.88
    high_flow_threshold_norm: float = 0.25
    high_flow_weight_max: float = 8.0
    extreme_quantile: float = 0.95
    extreme_sample_weight: float = 3.0
    peak_focal_gamma: float = 2.0
    # 三阶段训练（欠预测惩罚逐步增强）
    stage1_epochs: int = 300
    stage2_epochs: int = 700
    underpred_weight_stage2: float = 2.0
    underpred_weight_stage3: float = 3.0
    # 数据处理：未来时段降水按宽度分档取中点（模拟分档降水预报）
    #   0-50→25, 50-100→75, 100-150→125 ...（mm）；0 = 关闭分档
    future_rain_bucket: float = 5.0   # 档宽 50->5 (50mm 会把98.9%雨天压成同一档)
    # 未来 7 天蒸发填充方式（防止把未来实测 E 当作已知输入造成泄露）：
    #   True  -> 用该样本历史 60 天中 E_valid=1 的均值填充（推荐）
    #   False -> 沿用未来实测 E（原行为）
    evap_fill_hist_mean: bool = True
    seed: int = 42
    device: str = "auto"
    tag: str = "lstm_lam0"   # 纯 LSTM 基线(tag 独立,不覆盖任何已有权重)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def set_seed(seed: int = 42):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def _logit(x: float) -> float:
    x = min(max(x, 1e-4), 1 - 1e-4)
    return float(np.log(x / (1 - x)))


def _inv_softplus(x: float) -> float:
    return float(np.log(np.expm1(max(x, 1e-3))))


def get_device(cfg: Config) -> torch.device:
    if cfg.device == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(cfg.device)


COL_QOUT, COL_E, COL_EV = 1, 2, 3
COL_P = {4: "P_ld", 5: "P_ly", 6: "P_lsj", 7: "P_zjt"}


def load_hydro_data(file_path: str, sheet_name: str = "Sheet1",
                    start_date: str = "1998-01-01",
                    evap_valid_date: str = "2007-01-01"):
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)
    dates = pd.to_datetime(df.iloc[1:, 0], errors="coerce").values

    data = {}
    data["Qout"] = pd.to_numeric(df.iloc[1:, COL_QOUT], errors="coerce").astype(np.float32).values

    raw_E = pd.to_numeric(df.iloc[1:, COL_E], errors="coerce").astype(np.float32).values.copy()
    evap_valid = pd.to_numeric(df.iloc[1:, COL_EV], errors="coerce").fillna(1.0).astype(np.float32).values
    raw_E[evap_valid == 0] = 0.0
    data["E"] = raw_E
    data["E_valid"] = evap_valid

    for c, name in COL_P.items():
        data[name] = pd.to_numeric(df.iloc[1:, c], errors="coerce").astype(np.float32).values.copy()

    p_up = np.mean([data[k] for k in ST_UP], axis=0)     # 涟源+冷水江 = 上游
    p_loc = np.mean([data[k] for k in ST_LOC], axis=0)    # 娄底(站)+邹家滩 = 区间
    data["API_up"] = _api_series(p_up)
    data["API_loc"] = _api_series(p_loc)

    m = dates >= np.datetime64(start_date)
    sel = {k: (v[m] if isinstance(v, np.ndarray) else v) for k, v in data.items()}
    sel["dates"] = dates[m]

    n = len(sel["Qout"])
    n_valid = int(sel["E_valid"].sum())
    print(f"数据: {start_date} 起共 {n} 天 "
          f"({str(sel['dates'][0])[:10]} ~ {str(sel['dates'][-1])[:10]})")
    print(f"  蒸发有效: {n_valid} 天 ({evap_valid_date} 起)；缺失置零+掩码: {n - n_valid} 天")
    for k in COL_P.values():
        assert not np.isnan(sel[k]).any(), f"{k} 存在缺失!"
    assert not np.isnan(sel["Qout"]).any(), "Qout 存在缺失!"
    return sel


def _api_series(p: np.ndarray, k: float = 0.9) -> np.ndarray:
    api = np.empty_like(p, dtype=np.float32)
    acc = 0.0
    for i in range(len(p)):
        acc = p[i] + k * acc
        api[i] = acc
    return api


FEAT_ORDER = ["E", "P_ld", "P_ly", "P_lsj", "P_zjt",
              "API_up", "API_loc", "Qout", "E_valid"]
# ★ 站点索引一律从 FEAT_ORDER 派生(换站数不会错位)
_SIDX = {nm: k for k, nm in enumerate(FEAT_ORDER)}
IDX_P_ALL = [_SIDX[k] for k in FEAT_ORDER if k.startswith("P_")]
# ★ 上下游唯一定义处(校准与残差共用)
ST_UP, ST_LOC = ['P_lsj', 'P_zjt'], ['P_ld', 'P_ly']
IDX_P_UP = [_SIDX[k] for k in ST_UP]
IDX_P_LOC = [_SIDX[k] for k in ST_LOC]
I_API_UP, I_API_LOC, I_QOUT, I_E_VALID = _SIDX["API_up"], _SIDX["API_loc"], _SIDX["Qout"], _SIDX["E_valid"]


class HydroDataset:
    """X: [N, seq_len+pred_step, 11]；未来 Qout 列置 0（自回归填充）"""

    def __init__(self, data: Dict[str, Any], cfg: Config):
        self.seq_len, self.pred_step = cfg.seq_len, cfg.pred_step
        self.dates = data["dates"]
        feat = np.column_stack([data[k] for k in FEAT_ORDER]).astype(np.float32)
        self.feat_dim = feat.shape[1]

        # ---- 三划分(训练/验证/测试), 块间各留 seq_len 天隔离带 ----
        gap = int(self.seq_len)
        _yr = pd.DatetimeIndex(self.dates).year.values
        tr_hi = int(np.sum(_yr <= 2021))                      # 训练 2013-2021
        va_lo, va_hi = tr_hi + gap, int(np.sum(_yr <= 2023))  # 验证 2022-2023
        te_lo = va_hi + gap                                    # 测试 2024-2025
        assert te_lo < len(feat) - cfg.pred_step, "测试段为空" 
        feat_train = feat[:tr_hi]
        # E_valid 列固定 [0,1]，不参与 min/max
        self.f_min = np.concatenate([feat_train[:, :-1].min(axis=0), [0.0]])
        self.f_max = np.concatenate([feat_train[:, :-1].max(axis=0), [1.0]])
        self.y_min = float(data["Qout"][:tr_hi].min())
        self.y_max = float(data["Qout"][:tr_hi].max())

        self.feat_norm = self._norm(feat, self.f_min, self.f_max)
        # 重尾: Qout 用 log1p 归一化(y_max/中位数 = 95, 线性归一化会把普通日压到 0.01)
        self.y_lo = float(np.log1p(max(self.y_min, 0.0)))
        self.y_hi = float(np.log1p(max(self.y_max, 0.0)))
        self.y_norm = (np.log1p(np.maximum(data["Qout"], 0.0)) - self.y_lo) / (self.y_hi - self.y_lo + 1e-8)

        # 未来降水分档（模拟分档降水预报）所需：原始特征 + 档宽
        self.feat_raw = feat.astype(np.float32)
        self.future_rain_bucket = float(cfg.future_rain_bucket)
        self.evap_fill_hist_mean = bool(getattr(cfg, "evap_fill_hist_mean", True))
        # ★ 分档代表值 = 各站训练期条件期望 E[P|tier]（样本<5 回退中值）
        _BINS_7 = [0.1, 10.0, 25.0, 50.0, 100.0, 250.0]
        _MIDS_7 = [0.05, 5.0, 17.45, 37.45, 74.95, 174.95, 250.0]
        self.tier_vals = {}
        for _c in IDX_P_ALL:
            _pv = np.asarray(self.feat_raw[:tr_hi, _c], dtype=float)
            _ti = np.digitize(_pv, _BINS_7)
            _v = []
            for _k in range(7):
                _sel = _pv[_ti == _k]
                _v.append(float(_sel.mean()) if _sel.size >= 5 else _MIDS_7[_k])
            self.tier_vals[_c] = np.asarray(_v)

        X_tr, Y_tr, idx_tr = self._build_samples(0, tr_hi)
        X_va, Y_va, idx_va = self._build_samples(va_lo, va_hi)
        X_te, Y_te, idx_te = self._build_samples(te_lo, len(feat))

        self.X_train, self.Y_train = X_tr, Y_tr
        self.X_val, self.Y_val = X_va, Y_va
        self.val_idx = np.asarray(idx_va)
        self.val_dates = self.dates[self.val_idx]
        self.train_idx, self.test_idx = np.asarray(idx_tr), np.asarray(idx_te)
        self.X_test, self.Y_test = X_te, Y_te
        self.test_dates = self.dates[self.test_idx]

        print(f"样本: 训练={len(self.X_train)}  验证={len(self.X_val)}  测试={len(self.X_test)}  "
              f"(块间隔离 {gap} 天)")
        print(f"  验证期 {str(self.val_dates[0])[:10]} ~ {str(self.val_dates[-1])[:10]} ; "
              f"测试期 {str(self.test_dates[0])[:10]} ~ {str(self.test_dates[-1])[:10]}")
        print(f"  归一化: y_min={self.y_min:.1f} y_max={self.y_max:.1f}  (训练段 Qout 范围)")

    def _build_samples(self, start_idx: int, end_idx: int):
        X, Yq, idx_end = [], [], []
        for i in range(start_idx + self.seq_len, end_idx - self.pred_step):
            hist = self.feat_norm[i - self.seq_len:i, :]
            if self.future_rain_bucket > 0:
                fut = self._future_bucketed(i)          # 未来时段降水分档
            else:
                fut = self.feat_norm[i:i + self.pred_step, :].copy()
                fut[:, I_QOUT] = 0.0
            if getattr(self, "evap_fill_hist_mean", True):
                fut = self._fill_future_evap(i, fut)     # 未来蒸发用历史均值填充（防泄露）
            X.append(np.concatenate([hist, fut], axis=0))
            Yq.append(self.y_norm[i:i + self.pred_step])
            idx_end.append(i)
        if len(X) == 0:
            return (np.empty((0, self.seq_len + self.pred_step, self.feat_dim), dtype=np.float32),
                    np.empty((0, self.pred_step), dtype=np.float32), [])
        return (np.asarray(X, dtype=np.float32),
                np.asarray(Yq, dtype=np.float32), idx_end)

    def _fill_future_evap(self, i: int, fut_n: np.ndarray) -> np.ndarray:
        """未来 7 天蒸发用历史窗口均值填充（防止泄露未来实测 E）。

        均值只统计历史段中 E_valid=1 的天；若历史段全为缺失（如 2007 年前），
        则填 0 且掩码置 0，与该样本历史段保持一致。
        fut_n: 归一化空间的未来段 [pred_step, feat_dim]，原地修改并返回。
        """
        hist = self.feat_raw[i - self.seq_len:i]
        ok = hist[:, I_E_VALID] > 0.5
        span = self.f_max[0] - self.f_min[0] + 1e-12
        if ok.any():
            e_mean = float(hist[ok, 0].mean())
            fut_n[:, 0] = (e_mean - self.f_min[0]) / span
            fut_n[:, I_E_VALID] = 1.0
        else:
            fut_n[:, 0] = (0.0 - self.f_min[0]) / span
            fut_n[:, I_E_VALID] = 0.0
        return fut_n

    def _future_bucketed(self, i: int):
        """未来 7 天时段降水分档（模拟分档降水预报），并自洽重推未来 API。

        规则：降水 >0 时按 50mm 档取中点（0-50→25, 50-100→75, ...）；
              0mm 无雨日保持 0（不能把晴天改写成 25mm 中雨）。
        API 从历史最后一天的真实状态出发，用分档后的面雨逐日递推，
        保证输入中 P 与 API 自洽（与 load 阶段全程真实递推一致）。
        返回：归一化后的 fut（Qout 列已置 0）。
        """
        s, p = self.seq_len, self.pred_step
        fut = self.feat_raw[i:i + p].copy()             # 原始物理空间

        # 1) 未来 6 站降水分档：>0 → 所在档中点；0 保持 0
        for c in IDX_P_ALL:
            x = fut[:, c]
            pos = x > 0
            # 国标七级分档, 取各级中值; >=250 按 250
            BINS = [0.1, 10.0, 25.0, 50.0, 100.0, 250.0]
            MIDS = self.tier_vals.get(c, np.array([0.05, 5.0, 17.45, 37.45, 74.95, 174.95, 250.0]))
            idx7 = np.digitize(x[pos], BINS)
            fut[pos, c] = np.asarray(MIDS)[np.clip(idx7, 0, 6)]

        # 2) 未来 API：从 i-1 日真实状态开始，用分档面雨递推 api[t]=P[t]+k·api[t-1]
        api_up = self.feat_raw[i - 1, I_API_UP]
        api_loc = self.feat_raw[i - 1, I_API_LOC]
        k = 0.9
        for t in range(p):
            api_up = fut[t, IDX_P_UP].mean() + k * api_up
            api_loc = fut[t, IDX_P_LOC].mean() + k * api_loc
            fut[t, I_API_UP] = api_up
            fut[t, I_API_LOC] = api_loc

        fut_n = self._norm(fut, self.f_min, self.f_max)
        fut_n[:, I_QOUT] = 0.0
        return fut_n

    @staticmethod
    def _norm(arr, minv, maxv):
        return (arr - minv) / (maxv - minv + 1e-8)

    def denorm_y(self, y):
        return np.expm1(y * (self.y_hi - self.y_lo + 1e-8) + self.y_lo)

    def denorm_y_tensor(self, y):
        return torch.expm1(y * (self.y_hi - self.y_lo + 1e-8) + self.y_lo)


def nse_np(y, p):
    y, p = np.asarray(y, dtype=np.float64), np.asarray(p, dtype=np.float64)
    return 1.0 - np.sum((y - p) ** 2) / (np.sum((y - y.mean()) ** 2) + 1e-8)


FEAT_DESC = {
    "E": "蒸发 (mm/d)", "P_ld": "娄底降水 (mm)", "P_ly": "涟源降水 (mm)",
    "P_lsj": "冷水江降水 (mm)", "P_zjt": "邹家滩降水 (mm)",
    "": " (mm)", "API_up": "上游前期雨量 (mm)",
    "API_loc": "区间前期雨量 (mm)", "Qout": "出口流量 (m3/s)",
    "E_valid": "蒸发有效标志 (0/1)",
}


def print_feature_samples(dataset, cfg, n=None, which="train", save=None):
    """打印 n 条样本的 67 天序列：处理前（原始数据） vs 处理后（网络输入）。

    处理前 = output.xlsx 原始值（E 缺失显示 NaN）
    处理后 = 网络输入（E 缺失置 0 + 掩码；未来 7 天降水按国标七级取中值、API 重推、Qout 置 0）
    样本按位置等间隔选取：首、末 + 中间三条。
    """
    n = int(cfg.print_samples if n is None else n)
    if n <= 0:
        return
    X = dataset.X_train if which == "train" else dataset.X_test
    idx_all = dataset.train_idx if which == "train" else dataset.test_idx
    if len(X) == 0:
        print(f"[特征样本] {which} 集为空，跳过")
        return

    n = min(n, len(X))
    picks = np.linspace(0, len(X) - 1, n).astype(int)
    fmin, fmax = dataset.f_min, dataset.f_max
    s, p = dataset.seq_len, dataset.pred_step
    T = s + p
    P = IDX_P_ALL

    L = []

    def out(t=""):
        L.append(t)

    out()
    out("=" * 118)
    out(f"特征样本：处理前 vs 处理后（{which} 集共 {len(X)} 条；等间隔取 {n} 条：首 / 中间 3 条 / 末）")
    out("  处理前 = 原始数据（E 缺失显示 NaN）")
    out("  处理后 = 网络输入（E 缺失置 0 + 掩码；未来 7 天：蒸发用历史均值填充、降水按国标七级取中值、API 重推、Qout 置 0）")
    out("=" * 118)

    for j, k in enumerate(picks):
        e = int(idx_all[k])
        aft = X[k] * (fmax - fmin) + fmin             # 处理后
        bef = dataset.feat_raw[e - s: e + p]          # 处理前
        out()
        out(f"[样本 {j + 1}/{n}]  {which}集第 {k} 条   "
            f"历史 {str(dataset.dates[e - s])[:10]} ~ {str(dataset.dates[e - 1])[:10]}"
            f"  ->  预报起始 {str(dataset.dates[e])[:10]}   (H=历史 {s} 天, F=未来 {p} 天)")

        out()
        out("  --- 处理前（原始数据） ---")
        out("   t  日期          段      E" + "".join(f"{nm:>8}" for nm in
                                              ["P_ld", "P_ly", "P_lsj", "P_zjt",
                                               "", ""]) + f"{'Qout':>9}")
        for t in range(T):
            seg = "H" if t < s else "F"
            es = "NaN" if bef[t, I_E_VALID] < 0.5 else f"{bef[t, 0]:.2f}"
            out(f"  {t + 1:>3}  {str(dataset.dates[e - s + t])[:10]:<11}{seg:>3}{es:>7}"
                + "".join(f"{bef[t, i]:>8.1f}" for i in P) + f"{bef[t, I_QOUT]:>9.1f}")

        out()
        out("  --- 处理后（网络输入） ---")
        out("   t  日期          段      E  Ev"
            + "".join(f"{nm:>8}" for nm in ["P_ld", "P_ly", "P_lsj", "P_zjt",
                                            "", ""])
            + f"{'API_up':>8}{'API_loc':>8}{'Qout':>9}")
        for t in range(T):
            seg = "H" if t < s else "F"
            out(f"  {t + 1:>3}  {str(dataset.dates[e - s + t])[:10]:<11}{seg:>3}"
                f"{aft[t, 0]:>7.2f}{int(round(float(aft[t, I_E_VALID]))):>4d}"
                + "".join(f"{aft[t, i]:>8.1f}" for i in P)
                + f"{aft[t, I_API_UP]:>8.1f}{aft[t, I_API_LOC]:>8.1f}"
                f"{aft[t, I_QOUT]:>9.1f}")

    out()
    out("=" * 118)
    out()

    text = "\n".join(L)
    print(text)
    fn = save if save else getattr(cfg, "print_samples_file", "")
    if fn:
        with open(fn, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"[特征样本] 处理前后明细已保存到 {fn}")


def calibrate_physics(model, data, cfg, verbose=True):
    """方案A：用【训练段观测】率定物理参数 (k1, alpha, gamma)，再冻结。

    目标: min || Q(t) - k1*Q(t-1) - alpha*Qrun_gamma(t) ||^2
    gamma 外层网格搜索，(k1, alpha) 内层线性最小二乘。
    只用训练段，避免测试集泄漏。
    """
    dev = next(model.parameters()).device
    n_all = len(data["Qout"])
    _yr = pd.DatetimeIndex(data["dates"]).year.values
    n_tr = int(np.sum(_yr <= 2021))          # 与 HydroDataset 的按年切分一致

    def t_(x):
        return torch.as_tensor(np.asarray(x, dtype=np.float32), device=dev).unsqueeze(0)

    P_up_ = t_(np.mean([data[k] for k in ST_UP], axis=0))
    P_loc_ = t_(np.mean([data[k] for k in ST_LOC], axis=0))
    with torch.no_grad():
        R_up_raw = model.runoff_raw(P_up_, t_(data["API_up"]))
        R_loc_raw = model.runoff_raw(P_loc_, t_(data["API_loc"]))
        uh_up, uh_loc = model.get_uh(model.uh_n_up), model.get_uh(model.uh_n_loc)

    Qobs = np.asarray(data["Qout"], dtype=np.float64)
    y = Qobs[1:n_tr]
    x1 = Qobs[0:n_tr - 1]
    R_ref = 10.0

    # 基线：纯退水项
    k1_only = float(np.sum(y * x1) / (np.sum(x1 ** 2) + 1e-12))
    yh0 = k1_only * x1
    r2_0 = 1.0 - np.sum((y - yh0) ** 2) / (np.sum((y - y.mean()) ** 2) + 1e-12)

    best = None
    for gam in np.arange(1.0, cfg.calib_gamma_max + 1e-9, 0.1):
        with torch.no_grad():
            g = torch.tensor(float(gam), device=dev)
            Ru = (R_up_raw / R_ref) ** g * R_ref
            Rl = (R_loc_raw / R_ref) ** g * R_ref
            Qrun = (model.convolve_uh(Ru, uh_up, model.area_up)
                    + model.convolve_uh(Rl, uh_loc, model.area_loc)
                    ).squeeze(0).cpu().numpy().astype(np.float64)
        A = np.column_stack([x1, Qrun[1:n_tr]])
        # 洪峰加权：w = 1 + (Q/Q_ref)^2，让洪峰样本主导拟合
        w = 1.0 + (y / cfg.calib_flow_weight_ref) ** 2
        sw = np.sqrt(w)
        coef, *_ = np.linalg.lstsq(A * sw[:, None], y * sw, rcond=None)
        yh = A @ coef
        r2 = 1.0 - np.sum((y - yh) ** 2) / (np.sum((y - y.mean()) ** 2) + 1e-12)
        r2w = 1.0 - np.sum(w * (y - yh) ** 2) / (np.sum(w * (y - y.mean()) ** 2) + 1e-12)
        if best is None or r2w > best["r2w"]:
            best = dict(gamma=float(gam), k1=float(coef[0]), alpha=float(coef[1]),
                        r2=float(r2), r2w=float(r2w))

    if verbose:
        print("\n" + "=" * 84)
        print("【方案A】物理参数观测校准（仅用训练段，防泄漏）")
        print("=" * 84)
        print(f"  纯退水项基线 : k1={k1_only:.4f}                              R2={r2_0:.4f}")
        print(f"  校准结果     : k1={best['k1']:.4f}  alpha={best['alpha']:.4f}  "
              f"gamma={best['gamma']:.2f}   R2={best['r2']:.4f}  加权R2={best['r2w']:.4f}")
        _k1c, _ac = best["k1"], best["alpha"]
        _Qrun_c = None
        with torch.no_grad():
            g_ = torch.tensor(float(best["gamma"]), device=dev)
            Ru_ = (R_up_raw / 10.0) ** g_ * 10.0
            Rl_ = (R_loc_raw / 10.0) ** g_ * 10.0
            _Qrun_c = (model.convolve_uh(Ru_, uh_up, model.area_up)
                       + model.convolve_uh(Rl_, uh_loc, model.area_loc)
                       ).squeeze(0).cpu().numpy().astype(np.float64)[1:n_tr]
        _Yimp = np.clip(y - _k1c * x1, 0, None)
        for lo, hi, nm in [(100, 500, "中流量100-500"), (500, 1500, "高流量500-1500"),
                           (1500, 1e9, "洪峰>1500")]:
            sel = (y >= lo) & (y < hi)
            if sel.sum() < 5:
                continue
            print(f"    {nm:<16s} n={sel.sum():5d}  观测={_Yimp[sel].mean():8.2f}  "
                  f"物理={_ac * _Qrun_c[sel].mean():8.2f}  "
                  f"比值={_ac * _Qrun_c[sel].mean() / (_Yimp[sel].mean() + 1e-9):6.3f}")

    model.set_physics_params(k1=best["k1"], alpha=best["alpha"], gamma=best["gamma"])
    if cfg.freeze_physics:
        model.freeze_physics()
        if verbose:
            print("  -> 物理参数已【冻结】，训练中不再漂移")
    elif verbose:
        print("  -> 物理参数保持可训练（freeze_physics=False）")
    best["r2_baseline"] = r2_0
    best["k1_baseline"] = k1_only
    return best


class PhysicsLSTM(nn.Module):
    """朴素 LSTM：编码历史 60 天 → 逐日自回归 7 天；PINN 物理损失软约束。"""

    def __init__(self, cfg: Config):
        super().__init__()
        self.cfg = cfg
        self.seq_len, self.pred_step = cfg.seq_len, cfg.pred_step
        self.rain_days = cfg.rain_days
        self.CONV = 1000.0 / 86400.0
        self.register_buffer("area_up", torch.tensor(float(cfg.area_up)))
        self.register_buffer("area_loc", torch.tensor(float(cfg.area_loc)))
        self.register_buffer("storm_threshold", torch.tensor(float(cfg.storm_threshold)))

        def logit(x):
            x = min(max(x, 1e-4), 1 - 1e-4)
            return float(np.log(x / (1 - x)))

        def inv_softplus(x):
            return float(np.log(np.expm1(max(x, 1e-3))))

        # 物理参数
        self.k1_logit = nn.Parameter(torch.tensor(logit(cfg.k1_init)))

        # (1) 自由参数单位线（softmax 归一化）：Up(上游)/Loc(区间) x 正常/暴雨
        n = cfg.rain_days

        def _decay(a, r):
            return torch.tensor([a * (r ** i) for i in range(n)], dtype=torch.float32)

        self.uh_n_up = nn.Parameter(_decay(1.0, 0.80))    # 上游-正常（退水慢）
        self.uh_n_loc = nn.Parameter(_decay(1.0, 0.62))   # 区间-正常（退水快）
        self.uh_s_up = nn.Parameter(_decay(1.0, 0.68))    # 上游-暴雨
        self.uh_s_loc = nn.Parameter(_decay(1.0, 0.50))   # 区间-暴雨（最尖）

        # (2) SCS-CN 产流参数（CN 随 API 动态变化）
        self.cn_lo = nn.Parameter(torch.tensor(float(cfg.cn_lo_init)))
        self.cn_hi = nn.Parameter(torch.tensor(float(cfg.cn_hi_init)))
        self.coef_thr = nn.Parameter(torch.tensor(25.0))     # API 阈值（mm）
        self.coef_scale_log = nn.Parameter(torch.tensor(inv_softplus(12.0)))

        # (3)(4) 产流量级修正 alpha 与曲率 gamma（由诊断结论引入）
        self.alpha_run_log = nn.Parameter(torch.tensor(inv_softplus(cfg.alpha_run_init)))
        self.gamma_run_log = nn.Parameter(torch.tensor(inv_softplus(cfg.gamma_run_init - 1.0)))

        # 网络（⚠️ cu126/Windows：LSTM 内置 dropout + 多层退出崩溃 → 置 0）
        self.lstm = nn.LSTM(cfg.feat_dim, cfg.hidden_dim, cfg.lstm_layers, batch_first=True,
                            dropout=0.0)
        self.head = nn.Sequential(
            nn.Linear(cfg.hidden_dim, 64), nn.ReLU(), nn.Dropout(cfg.dropout),
            nn.Linear(64, 32), nn.ReLU(), nn.Dropout(cfg.dropout),
            nn.Linear(32, 1),
        )
        self._init_weights()

    def _init_weights(self):
        for name, p in self.named_parameters():
            if "lstm" in name and "weight" in name and p.dim() >= 2:
                nn.init.orthogonal_(p)
            elif "head" in name and "weight" in name and p.dim() >= 2:
                nn.init.xavier_uniform_(p)

    def get_k1(self):
        return torch.sigmoid(self.k1_logit)

    def get_uh(self, raw):
        # (1) 自由参数单位线：softmax 保证 sum(u)=1，长度 = rain_days
        return F.softmax(raw, dim=0)

    def _cn(self, api):
        # (2) SCS-CN 曲线数：API 越高 -> CN 越大（干期 55 -> 湿润期 92）
        cn_lo = torch.clamp(self.cn_lo, 30.0, 70.0)
        cn_hi = torch.clamp(self.cn_hi, 75.0, 98.0)
        scale = F.softplus(self.coef_scale_log) + 1.0
        return cn_lo + (cn_hi - cn_lo) * torch.sigmoid((api - self.coef_thr) / scale)

    def runoff_raw(self, P, api):
        # (2) SCS-CN 原始产流：R = (P-Ia)^2/(P-Ia+0.8S) if P>Ia else 0
        #     S = 25400/CN - 254 (mm)，Ia = 0.2S；自带初损与非线性饱和
        cn = self._cn(api)
        S = 25400.0 / cn - 254.0
        Ia = 0.2 * S
        Pe = P - Ia
        R = torch.where(Pe > 0, Pe ** 2 / (Pe + 0.8 * S + 1e-6), torch.zeros_like(P))
        return torch.clamp(R, min=0.0)

    def apply_alpha_gamma(self, R):
        # (3) 量级修正 alpha (4) 曲率修正 gamma>1（压低中流量、抬高洪峰）
        alpha = F.softplus(self.alpha_run_log)
        gamma = F.softplus(self.gamma_run_log) + 1.0
        R_ref = 10.0    # 参考产流深 (mm)，保持量纲
        return alpha * (R / R_ref) ** gamma * R_ref

    def runoff_scs(self, P, api):
        return self.apply_alpha_gamma(self.runoff_raw(P, api))

    def set_physics_params(self, k1=None, alpha=None, gamma=None):
        # 写入物理参数（方案A 校准用）
        dev = self.k1_logit.device
        with torch.no_grad():
            if k1 is not None:
                self.k1_logit.copy_(torch.tensor(_logit(float(k1)), device=dev))
            if alpha is not None:
                self.alpha_run_log.copy_(torch.tensor(_inv_softplus(float(alpha)), device=dev))
            if gamma is not None:
                self.gamma_run_log.copy_(torch.tensor(_inv_softplus(float(gamma) - 1.0), device=dev))

    def freeze_physics(self):
        # 方案A：冻结物理参数，避免其"迁就 LSTM 预测"而漂移
        self.k1_logit.requires_grad_(False)
        self.alpha_run_log.requires_grad_(False)
        self.gamma_run_log.requires_grad_(False)

    def convolve_uh(self, R, rain_k, area):
        R_pad = F.pad(R.unsqueeze(1), (self.rain_days - 1, 0))
        k = rain_k.flip(0).view(1, 1, -1)
        Q = F.conv1d(R_pad, k).squeeze(1)
        return torch.clamp(Q, 0.0, 1e6) * area * self.CONV

    def storm_mask_causal(self, P_area):
        m = (P_area > self.storm_threshold).float().unsqueeze(1)
        m = F.pad(m, (2, 0))
        kernel = torch.ones(1, 1, 3, device=P_area.device)
        return (F.conv1d(m, kernel).squeeze(1) > 0).float()

    def forward(self, x):
        """x: [B, seq_len+pred_step, 11] → Qout_pred [B, pred_step]"""
        hist = x[:, :self.seq_len, :]
        fut = x[:, self.seq_len:, :]

        _, (h, c) = self.lstm(hist)          # 标准 LSTM 编码，无注意力增强
        qout_prev = hist[:, -1:, I_QOUT:I_QOUT + 1]
        outs = []
        for t in range(self.pred_step):
            known = torch.cat([
                fut[:, t:t + 1, :I_QOUT],               # E+P6+API2 = 9 维
                fut[:, t:t + 1, I_E_VALID:I_E_VALID + 1]  # E_valid = 1 维
            ], dim=-1)                                   # 10 维（实测/预报输入）
            sf = torch.cat([known, qout_prev], dim=-1)   # 11 维
            step_out, (h, c) = self.lstm(sf, (h, c))
            q_t = F.softplus(self.head(step_out[:, -1, :]))
            outs.append(q_t)
            qout_prev = q_t.unsqueeze(1)
        return torch.cat(outs, dim=1)

    def compute_physics_loss(self, x, Q_pred, dataset):
        device = x.device
        f_min = torch.as_tensor(dataset.f_min, dtype=torch.float32, device=device)
        f_max = torch.as_tensor(dataset.f_max, dtype=torch.float32, device=device)
        rng = (f_max - f_min + 1e-8)

        hist = x[:, :self.seq_len, :].float()
        fut = x[:, self.seq_len:, :].float()
        Q_pred = Q_pred.float()

        hist_real = hist * rng + f_min
        fut_real = fut * rng + f_min
        Qout_hist_real = hist_real[:, :, I_QOUT]
        Qout_fut_real = dataset.denorm_y_tensor(Q_pred)

        def full(col_idx):
            return torch.cat([hist_real[:, :, col_idx], fut_real[:, :, col_idx]], dim=1)

        P_up_full = full(IDX_P_UP).mean(dim=-1)
        P_loc_full = full(IDX_P_LOC).mean(dim=-1)
        P_all = 0.5 * (P_up_full + P_loc_full)
        API_up_full = full([I_API_UP])[:, :, 0]
        API_loc_full = full([I_API_LOC])[:, :, 0]

        # (2) 分区 SCS-CN 产流（含初损与非线性饱和）
        R_up = self.runoff_scs(P_up_full, API_up_full)
        R_loc = self.runoff_scs(P_loc_full, API_loc_full)

        # (1) 自由参数单位线（Up/Loc 分区独立，正常/暴雨两套）
        uh_n_up, uh_n_loc = self.get_uh(self.uh_n_up), self.get_uh(self.uh_n_loc)
        uh_s_up, uh_s_loc = self.get_uh(self.uh_s_up), self.get_uh(self.uh_s_loc)
        storm = self.storm_mask_causal(P_all)
        s = self.seq_len

        Qrun_n = (self.convolve_uh(R_up, uh_n_up, self.area_up)
                  + self.convolve_uh(R_loc, uh_n_loc, self.area_loc))
        Qrun_s = (self.convolve_uh(R_up, uh_s_up, self.area_up)
                  + self.convolve_uh(R_loc, uh_s_loc, self.area_loc))
        Qrun = Qrun_n * (1 - storm) + Qrun_s * storm
        Qrun_fut = Qrun[:, s:s + self.pred_step]

        k1 = self.get_k1()
        Qout_prev = torch.cat([Qout_hist_real[:, s - 1:s], Qout_fut_real[:, :-1]], dim=1)
        rhs = k1 * Qout_prev + Qrun_fut

        res = (Qout_fut_real - rhs) / (Qout_fut_real.abs() + rhs.abs() + 1e-3)
        # 【流量门控】物理方程只在洪峰期可信（校准已按洪峰加权）：
        #   低流量 -> 权重压到 phys_gate_floor；洪峰期 -> 权重升到 1
        gate = (self.cfg.phys_gate_floor
                + (1.0 - self.cfg.phys_gate_floor) * torch.sigmoid(
                    (Qout_fut_real.detach() - self.cfg.phys_q_gate) / self.cfg.phys_q_width))
        mean_flow = Qout_fut_real.mean(dim=1, keepdim=True)
        w_flow = 1.0 + 2.0 * torch.sigmoid((mean_flow - 300.0) / 100.0)
        loss_physics = torch.mean((res * w_flow * gate) ** 2)

        # (5) 单位线平滑惩罚：抑制非物理的双峰/锯齿形状（二阶差分）
        loss_uh = torch.zeros((), device=device)
        for _uh in (uh_n_up, uh_n_loc, uh_s_up, uh_s_loc):
            loss_uh = loss_uh + torch.sum((_uh[2:] - 2.0 * _uh[1:-1] + _uh[:-2]) ** 2)
        loss_physics = loss_physics + self.cfg.uh_smooth_weight * loss_uh

        if not torch.isfinite(loss_physics):
            loss_physics = torch.zeros((), device=device)

        with torch.no_grad():
            metrics = {
                "loss_physics": float(loss_physics),
                "k1": float(k1),
                "cn_lo": float(torch.clamp(self.cn_lo, 30.0, 88.0)),
                "cn_hi": float(torch.clamp(self.cn_hi, 60.0, 98.0)),
                "alpha_run": float(F.softplus(self.alpha_run_log)),
                "gamma_run": float(F.softplus(self.gamma_run_log) + 1.0),
                "coef_thr": float(self.coef_thr),
                "storm_ratio": float(storm.mean()),
            }
        return loss_physics, metrics


def get_stage_weights(epoch, cfg: Config):
    if epoch < cfg.stage1_epochs:
        return 0.0, 0.0, 1
    if epoch < cfg.stage2_epochs:
        prog = (epoch - cfg.stage1_epochs) / max(1, cfg.stage2_epochs - cfg.stage1_epochs)
        return prog, cfg.underpred_weight_stage2 * prog, 2
    return 1.0, cfg.underpred_weight_stage3, 3


def data_loss_fn(pred, target, cfg: Config, day_w, high_ratio, underpred_w):
    """C0 纯 MSE: 无峰值focal/低流量log/流量加权"""
    return ((pred - target) ** 2).mean()


@torch.no_grad()
def evaluate(model, dataset, device, chunk=512, which="test"):
    """which: train / val / test —— 验证集选点, 测试集只评估一次"""
    model.eval()
    _X, _Y = {"train": (dataset.X_train, dataset.Y_train),
              "val":   (dataset.X_val,   dataset.Y_val)}.get(which, (dataset.X_test, dataset.Y_test))
    X = torch.as_tensor(_X)
    preds = []
    for i in range(0, len(X), chunk):
        q = model(X[i:i + chunk].to(device))
        preds.append(q.float().cpu().numpy())
    P = dataset.denorm_y(np.concatenate(preds, axis=0))
    Y = dataset.denorm_y(_Y)
    out = {
        "pred": P, "true": Y,
        "nse": nse_np(Y, P),
        "rmse": float(np.sqrt(np.mean((Y - P) ** 2))),
        "nse_days": [nse_np(Y[:, d], P[:, d]) for d in range(Y.shape[1])],
    }
    thr = np.percentile(Y, 90)
    m = Y.flatten() > thr
    out["nse_peak"] = nse_np(Y.flatten()[m], P.flatten()[m]) if m.sum() > 5 else float("nan")
    lm = Y[:, 0] < 100.0
    out["nse_low"] = nse_np(Y[lm], P[lm]) if lm.sum() > 10 else float("nan")
    out["peak_pred"], out["peak_true"] = float(P.max()), float(Y.max())
    return out


def train_model(model, dataset, cfg: Config, device):
    X_tr = torch.as_tensor(dataset.X_train)
    Y_tr = torch.as_tensor(dataset.Y_train)
    loader = DataLoader(TensorDataset(X_tr, Y_tr), batch_size=cfg.batch_size,
                        shuffle=True, drop_last=True, pin_memory=(device.type == "cuda"))

    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    day_w = torch.tensor([1.0, 0.96, 0.92, 0.89, 0.86, 0.83, 0.80], device=device)[:cfg.pred_step]

    history = {"train_loss": [], "data_loss": [], "physics_loss": [],
               "test_nse": [], "k1": [], "cn_hi": []}

    print("\n" + "=" * 84)
    print(f"训练 PINN-LSTM（SCS-CN 产流 + 自由单位线）| 物理权重={cfg.physics_weight} "
          f"(预热 {cfg.physics_warmup_epochs} ep) | 按 F2 提前结束")
    print("=" * 84)

    stop = threading.Event()

    def listen():
        try:
            import keyboard
            keyboard.wait("f2")
            stop.set()
        except Exception:
            pass

    threading.Thread(target=listen, daemon=True).start()

    best_nse, best_epoch, patience = -1e9, 0, 0
    ckpt = f"best_model_{cfg.tag}.pth"

    for epoch in range(cfg.epochs):
        if stop.is_set():
            print(f"训练提前结束于 Epoch {epoch}")
            break
        model.train()
        ep_loss = ep_data = ep_phys = 0.0
        pw = (min(cfg.physics_weight, cfg.physics_weight * epoch / cfg.physics_warmup_epochs)
              if cfg.physics_warmup_epochs > 0 else cfg.physics_weight)
        high_ratio, underpred_w, stage = get_stage_weights(epoch, cfg)
        last_metrics = {}

        for bx, by in loader:
            if stop.is_set():
                break
            bx, by = bx.to(device), by.to(device)
            q = model(bx)
            loss_data = data_loss_fn(q, by, cfg, day_w, high_ratio, underpred_w)
            loss_phys, last_metrics = model.compute_physics_loss(bx, q, dataset)
            total = loss_data + pw * loss_phys

            opt.zero_grad(set_to_none=True)
            total.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            opt.step()

            ep_loss += float(total)
            ep_data += float(loss_data)
            ep_phys += float(loss_phys)

        if stop.is_set():
            break
        nb = max(1, len(loader))

        ev = evaluate(model, dataset, device, which="val")

        history["train_loss"].append(ep_loss / nb)
        history["data_loss"].append(ep_data / nb)
        history["physics_loss"].append(ep_phys / nb)
        history["test_nse"].append(ev["nse"])
        history["k1"].append(last_metrics.get("k1", float("nan")))
        history["cn_hi"].append(last_metrics.get("cn_hi", float("nan")))

        if ev["nse"] > best_nse:
            best_nse, best_epoch, patience = ev["nse"], epoch, 0
            torch.save(model.state_dict(), ckpt)
        else:
            patience += 1

        if epoch % 100 == 0 or epoch == cfg.epochs - 1:
            print(f"Ep {epoch:4d} [S{stage}] loss={ep_loss / nb:.4e} | NSE={ev['nse']:.4f} "
                  f"(best {best_nse:.4f}) | NSE_peak={ev['nse_peak']:.3f} NSE_low={ev['nse_low']:.3f} "
                  f"| 峰值 {ev['peak_pred']:.0f}/{ev['peak_true']:.0f} "
                  f"| phys={ep_phys / nb:.3e} k1={last_metrics.get('k1', float('nan')):.3f}")

        if patience >= cfg.early_stop_patience:
            print(f"早停于 Epoch {epoch}（最佳 Epoch {best_epoch}, 验证 NSE={best_nse:.4f}）")
            break

    print(f"\n最佳验证 NSE = {best_nse:.4f} @ Epoch {best_epoch}（权重按验证集选择）")
    try:
        model.load_state_dict(torch.load(ckpt, map_location=device))
        print(f"已加载最佳模型 {ckpt}")
    except Exception as e:
        print(f"加载最佳模型失败({e})，使用当前模型")
    return history


def plot_results(model, dataset, history, cfg: Config, device):
    ev = evaluate(model, dataset, device)
    Y, P = ev["true"], ev["pred"]
    nse_days = ev["nse_days"]

    print(f"\n[PINN-LSTM | naive + composite loss | results]")
    print(f"NSE={ev['nse']:.4f}  RMSE={ev['rmse']:.2f}  NSE_peak={ev['nse_peak']:.4f}  "
          f"NSE_low={ev['nse_low']:.4f}")
    print("Per-lead NSE: " + " ".join(f"D{d + 1}={v:.4f}" for d, v in enumerate(nse_days)))
    print(f"Peak: predicted {ev['peak_pred']:.0f} / observed {ev['peak_true']:.0f} "
          f"({100 * (ev['peak_pred'] / max(ev['peak_true'], 1e-6) - 1):+.1f}%)")

    ep = range(len(history["train_loss"]))
    fig = plt.figure(figsize=(20, 12))
    gs = fig.add_gridspec(2, 3, hspace=0.35, wspace=0.3)

    ax = fig.add_subplot(gs[0, 0])
    ax.plot(ep, history["train_loss"], label="Total loss", lw=1)
    ax.plot(ep, history["data_loss"], label="Data loss (composite)", lw=1)
    ax.plot(ep, history["physics_loss"], label="Physics loss", lw=1)
    ax.set_yscale("log"); ax.set_xlabel("Epoch"); ax.set_title("Loss convergence")
    ax.legend(); ax.grid(alpha=0.3)

    t = np.arange(len(Y))
    for j, d in enumerate([0, 3, 6]):
        ax = fig.add_subplot(gs[1, j])
        ax.plot(t, Y[:, d], "b-", lw=1.3, alpha=0.8, label="Observed")
        ax.plot(t, P[:, d], "r--", lw=1.3, alpha=0.8, label="Predicted")
        ax.set_xlabel("Test sample index"); ax.set_ylabel("Discharge (m³/s)")
        ax.set_title(f"Lead {d + 1} prediction (NSE={nse_days[d]:.4f})")
        ax.legend(); ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[0, 1])
    bars = ax.bar(np.arange(1, len(nse_days) + 1), nse_days, color="skyblue", edgecolor="navy")
    for b, v in zip(bars, nse_days):
        ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.01, f"{v:.3f}",
                ha="center", va="bottom", fontsize=9)
    ax.set_xlabel("Lead time (days)"); ax.set_ylabel("NSE"); ax.set_title("NSE by lead time")
    ax.grid(alpha=0.3, axis="y")

    ax = fig.add_subplot(gs[0, 2])
    ax.scatter(Y.flatten(), P.flatten(), s=8, alpha=0.3)
    mx = float(max(Y.max(), P.max()))
    ax.plot([0, mx], [0, mx], "r--", lw=1.5)
    ax.set_xlabel("Observed (m³/s)"); ax.set_ylabel("Predicted (m³/s)")
    ax.set_title(f"Predicted vs observed (NSE={ev['nse']:.4f})"); ax.grid(alpha=0.3)

    plt.suptitle(f"PINN-LSTM | NSE={ev['nse']:.4f} RMSE={ev['rmse']:.1f} "
                 f"peak {ev['peak_pred']:.0f}/{ev['peak_true']:.0f}",
                 fontsize=14, fontweight="bold")
    out_png = f"prediction_{cfg.tag}.png"
    plt.savefig(out_png, dpi=150, bbox_inches="tight")
    if os.environ.get("HYDRO_NO_SHOW", "") == "1":
        plt.close(fig)
    else:
        try:
            plt.show()
        except Exception:
            pass
    print(f"Figure saved: {out_png}")
    return ev


def main():
    cfg = Config()
    if len(sys.argv) > 1:
        cfg.seed = int(sys.argv[1])
        cfg.tag = "b13_w1ce_s%d" % cfg.seed      # ★ 与 C 配置的 seedN 区分
        print("[seed] seed=%d tag=%s" % (cfg.seed, cfg.tag))
    set_seed(cfg.seed)
    device = get_device(cfg)
    print(f"设备: {device}  torch={torch.__version__}")

    data = load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
    dataset = HydroDataset(data, cfg)
    print_feature_samples(dataset, cfg)
    cfg.feat_dim = dataset.feat_dim

    model = PhysicsLSTM(cfg).to(device)
    if cfg.calibrate_physics:
        calibrate_physics(model, data, cfg)
    print(f"参数量: {sum(p.numel() for p in model.parameters()):,}")
    with torch.no_grad():
        print(f"初值: k1={model.get_k1():.3f}  CN [{model.cn_lo.item():.0f} -> {model.cn_hi.item():.0f}]")
        print(f"      alpha={torch.nn.functional.softplus(model.alpha_run_log).item():.3f}"
              f"  gamma={torch.nn.functional.softplus(model.gamma_run_log).item() + 1.0:.3f}")
        print(f"  UH_up (正常) = {[round(float(v), 3) for v in model.get_uh(model.uh_n_up)]}")
        print(f"  UH_loc(正常) = {[round(float(v), 3) for v in model.get_uh(model.uh_n_loc)]}")

    history = train_model(model, dataset, cfg, device)
    ev = plot_results(model, dataset, history, cfg, device)

    torch.save({"model_state_dict": model.state_dict(), "config": cfg.to_dict(),
                "f_min": dataset.f_min.tolist(), "f_max": dataset.f_max.tolist(),
                "y_min": dataset.y_min, "y_max": dataset.y_max,
                "feat_order": FEAT_ORDER, "nse": ev["nse"]}, f"model_{cfg.tag}.pth")
    print(f"模型已保存: model_{cfg.tag}.pth")


if __name__ == "__main__":
    main()
