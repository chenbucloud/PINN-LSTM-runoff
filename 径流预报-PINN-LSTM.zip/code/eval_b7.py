# -*- coding: utf-8 -*-
"""直接加载 B7 权重在测试集重评, 与论文数字对照"""
import importlib.util, numpy as np, torch, io, sys
def loadmod(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m            # ★ dataclass 需要模块已注册
    spec.loader.exec_module(m); return m
B7 = loadmod("B7-A1.py", "b7base")
cfg0 = B7.Config(); dev = B7.get_device(cfg0)
data = B7.load_hydro_data(cfg0.file_path, cfg0.sheet_name, cfg0.start_date, cfg0.evap_valid_date)
ds = B7.HydroDataset(data, cfg0); cfg0.feat_dim = ds.feat_dim
ARMS = [("A0","B7-A0.py","b7_a0_s%d",0.8447,0.1138),("A1","B7-A1.py","b7_a1_s%d",0.9277,0.0064),
        ("A2","B7-A2.py","b7_a2_s%d",0.9100,0.0153),("A3","B7-A3.py","b7_a3_s%d",0.8909,0.0575),
        ("A4","B7-A4.py","b7_a4_s%d",0.9047,0.0283),("B0","B7-A0CE.py","b7_a0ce_s%d",0.9009,0.0295),
        ("B1","B7-A1CE.py","b7_a1ce_s%d",0.9063,0.0177)]
print("%-4s %-30s %-18s %s" % ("臂","逐种子 NSE","均值±sd","论文值"))
for name, sc, tag, pm, ps in ARMS:
    try:
        M = loadmod(sc, "m_" + name)
        cfg = M.Config(); cfg.feat_dim = ds.feat_dim
        vals, used = [], []
        for s in range(1, 6):
            fn = "best_model_%s.pth" % (tag % s)
            try: ck = torch.load(fn, map_location=dev)
            except FileNotFoundError: continue
            model = M.PhysicsLSTM(cfg).to(dev)
            model.load_state_dict(ck["model_state_dict"] if "model_state_dict" in ck else ck)
            ev = M.evaluate(model, ds, dev)
            vals.append(ev["nse"]); used.append(s)
        if not vals: print("  %-3s 无权重 ✗" % name); continue
        a = np.array(vals)
        ok = abs(a.mean() - pm) < 1e-3
        print("  %-3s %-30s %.4f±%.4f  %s  论文 %.4f±%.4f %s" % (name,
              " ".join("%.3f" % v for v in a), a.mean(), a.std(ddof=1) if len(a)>1 else 0,
              "", pm, ps, "✓" if ok else "✗"))
    except Exception as e:
        print("  %-3s 失败: %s" % (name, str(e)[:70]))