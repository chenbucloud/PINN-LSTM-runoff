# -*- coding: utf-8 -*-
"""每臂 x 5 个训练种子 -> 确定性梯度诊断 -> 均值±sd"""
import io, os, numpy as np, contextlib
from diag_fixed import diag
ARMS = [("榔梨 A0", "B7-A0e100.py", "best_model_b7_a0e100_s%d.pth"),
        ("榔梨 A1", "B7-A1e100.py", "best_model_b7_a1e100_s%d.pth"),
        ("榔梨 A2", "B7-A2e100.py", "best_model_b7_a2e100_s%d.pth"),
        ("榔梨 A3", "B7-A3e100.py", "best_model_b7_a3e100_s%d.pth"),
        ("榔梨 A4", "B7-A4e100.py", "best_model_b7_a4e100_s%d.pth"),
        ("涟水 A0", "B13-A0e100.py", "best_model_a0e100_s%d.pth"),
        ("涟水 A1", "B13-W1.py", "best_model_b13_a1w1_s%d.pth"),
        ("涟水 A2", "B13-W2.py", "best_model_b13_w2_s%d.pth"),
        ("涟水 A3", "B13-W4.py", "best_model_b13_w4_s%d.pth"),
        ("涟水 A4", "B13-W5.py", "best_model_b13_w5_s%d.pth")]
print("%-10s %-40s %-20s %s" % ("臂", "五种子 cos", "cos 均值±sd", "η 均值±sd"), flush=True)
rows = []
for tag, sc, ck in ARMS:
    cs, es, ns = [], [], []
    for s in range(1, 6):
        f = ck % s
        if not os.path.exists(f): continue
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            r = diag(tag, sc, f)
        if r: cs.append(r[0]); es.append(r[1]); ns.append(r[2])
    if not cs:
        print("%-10s 缺权重 ✗" % tag, flush=True); continue
    c, e = np.array(cs), np.array(es)
    rows.append((tag, c, e, np.array(ns)))
    print("%-10s %-40s %+.4f±%.4f      %.4f±%.4f" % (tag, " ".join("%+.3f" % v for v in c),
          c.mean(), c.std(ddof=1) if len(c) > 1 else 0.0,
          e.mean(), e.std(ddof=1) if len(e) > 1 else 0.0), flush=True)
np.savez("diag5.npz", tags=[r[0] for r in rows], cos=[r[1] for r in rows],
         eta=[r[2] for r in rows], nse=[r[3] for r in rows])
print("\n已存 diag5.npz ✓", flush=True)