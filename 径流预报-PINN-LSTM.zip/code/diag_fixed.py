# -*- coding: utf-8 -*-
"""确定性梯度诊断: 关 dropout + 固定种子 + 全测试窗口固定顺序"""
import os, sys, io, random, importlib.util, contextlib, numpy as np, torch
os.environ["HYDRO_NO_SHOW"] = "1"
SEED = 0
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
if torch.cuda.is_available(): torch.cuda.manual_seed_all(SEED)
torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False

PHYS = ("k1_logit","uh_n_up","uh_n_loc","uh_s_up","uh_s_loc",
        "cn_lo","cn_hi","coef_thr","coef_scale_log","alpha_run_log","gamma_run_log")

def load(f):
    spec = importlib.util.spec_from_file_location("m_" + f.replace("-","_").replace(".py",""), f)
    M = importlib.util.module_from_spec(spec); sys.modules[spec.name] = M
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(M)
    return M

def flat(gs, ps):
    return torch.cat([(g if g is not None else torch.zeros_like(p)).reshape(-1) for g, p in zip(gs, ps)])

def diag(tag, script, ckpt, chunk=64):
    M = load(script)
    with contextlib.redirect_stdout(io.StringIO()):
        cfg = M.Config(); dev = M.get_device(cfg)
        data = M.load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
        ds = M.HydroDataset(data, cfg); cfg.feat_dim = ds.feat_dim
    mo = M.PhysicsLSTM(cfg).to(dev)
    w = torch.load(ckpt, map_location=dev, weights_only=False)
    mo.load_state_dict(w if "model_state_dict" not in w else w["model_state_dict"])
    # ★ 只关 dropout, 其余保持 train 以便反传
    mo.train()
    for m in mo.modules():
        if isinstance(m, torch.nn.Dropout): m.eval()
    torch.manual_seed(SEED)
    day_w = torch.tensor([1.0,0.96,0.92,0.89,0.86,0.83,0.80], device=dev)[:cfg.pred_step]
    hr, uw, _ = M.get_stage_weights(cfg.epochs, cfg)
    X = torch.as_tensor(ds.X_test, dtype=torch.float32, device=dev)
    Y = torch.as_tensor(ds.Y_test, dtype=torch.float32, device=dev)
    named = [(n,p) for n,p in mo.named_parameters() if p.requires_grad]
    params = [p for _, p in named]          # ★ autograd 只接受张量
    gd_l, gp_l = [], []
    for b in range(0, len(X), chunk):
        xb, yb = X[b:b+chunk], Y[b:b+chunk]
        q = mo(xb)
        ld = M.data_loss_fn(q, yb, cfg, day_w, hr, uw)
        gd = flat(torch.autograd.grad(ld, params, retain_graph=True, allow_unused=True), params)
        lp = mo.compute_physics_loss(xb, q, ds)
        if lp is None: print("  无 compute_physics_loss ✗"); return
        lp_t = lp[0] if isinstance(lp, (tuple, list)) else lp
        gpp = flat(torch.autograd.grad(lp_t, params, allow_unused=True), params)
        gd_l.append(gd.detach()); gp_l.append(gpp.detach())
    gd = torch.cat(gd_l); gp = torch.cat(gp_l)
    cos = float(torch.dot(gd, gp) / (gd.norm()*gp.norm() + 1e-12))
    share = float(gp.norm()**2 / (gd.norm()**2 + gp.norm()**2 + 1e-12))
    nse = M.evaluate(mo, ds, dev)["nse"]
    print("%-18s NSE=%.4f | cos_all=%+.4f | 物理梯度占比=%.4f | |Gp|=%.3e |Gd|=%.3e" % (
        tag, nse, cos, share, float(gp.norm()), float(gd.norm())), flush=True)
    return cos, share, nse