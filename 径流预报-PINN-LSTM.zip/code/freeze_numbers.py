# -*- coding: utf-8 -*-
"""唯一数据源: 全部权重 evaluate() 全精度 → numbers_final.csv"""
import importlib.util, sys, io, contextlib, csv, torch, numpy as np
def load(p, n):
    sp = importlib.util.spec_from_file_location(n, p); M = importlib.util.module_from_spec(sp)
    sys.modules[n] = M
    with contextlib.redirect_stdout(io.StringIO()): sp.loader.exec_module(M)
    return M
ARMS = [
 ("C1","A0","B7-A0e100.py","b7_a0e100"), ("C1","A1","B7-A1e100.py","b7_a1e100"),
 ("C1","A2","B7-A2e100.py","b7_a2e100"), ("C1","A3","B7-A3e100.py","b7_a3e100"),
 ("C1","A4","B7-A4e100.py","b7_a4e100"), ("C1","B0","B7-A0CEe100.py","b7_a0cee100"),
 ("C1","B1","B7-A1CEe100.py","b7_a1cee100"),
 ("C2","A0","B13-A0e100.py","a0e100"), ("C2","A1","B13-W1.py","b13_a1w1"),
 ("C2","A2","B13-W2.py","b13_w2"), ("C2","A3","B13-W4.py","b13_w4"),
 ("C2","A4","B13-W5.py","b13_w5"), ("C2","B0","B13-A0CE.py","b13_a0ce"),
 ("C2","B1","B13-A1CE.py","b13_w1ce"),
]
rows = []
for basin, arm, script, tag in ARMS:
    try:
        M = load(script, "m_%s_%s" % (basin, arm))
        with contextlib.redirect_stdout(io.StringIO()):
            cfg = M.Config(); dev = M.get_device(cfg)
            data = M.load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
            ds = M.HydroDataset(data, cfg); cfg.feat_dim = ds.feat_dim
        vals = []
        for s in range(1, 6):
            f = "best_model_%s_s%d.pth" % (tag, s)
            c = M.Config(); c.feat_dim = ds.feat_dim
            mo = M.PhysicsLSTM(c).to(dev)
            w = torch.load(f, map_location=dev, weights_only=False)
            mo.load_state_dict(w if "model_state_dict" not in w else w["model_state_dict"])
            with contextlib.redirect_stdout(io.StringIO()):
                vals.append(M.evaluate(mo, ds, dev)["nse"])
        a = np.array(vals)
        rows.append([basin, arm, len(a)] + ["%.6f" % v for v in a] +
                    ["%.6f" % a.mean(), "%.6f" % a.std(ddof=1), "%.6f" % a.min(), "%.6f" % a.max()])
        print("%s %s n=%d mean=%.4f sd=%.4f min=%.4f max=%.4f" % (basin, arm, len(a), a.mean(), a.std(ddof=1), a.min(), a.max()), flush=True)
    except Exception as e:
        print("%s %s 失败 %s" % (basin, arm, str(e)[:80]), flush=True)
with open("numbers_final.csv", "w", newline="", encoding="utf-8-sig") as f:
    w = csv.writer(f); w.writerow(["basin","arm","n","s1","s2","s3","s4","s5","mean","sd","min","max"])
    w.writerows(rows)
print("\nnumbers_final.csv ✓ (%d 臂)" % len(rows))