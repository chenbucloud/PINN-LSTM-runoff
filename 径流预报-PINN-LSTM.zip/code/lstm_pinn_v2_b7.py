# -*- coding: utf-8 -*-
"""
LSTM-PINN 流域日径流 7 天逐日自回归预报
=========================================

任务约束：
  1) 7 天逐日自回归预报；
  2) 历史样本长度（输入窗口）= 60 天；
  3) 未来降水按国标（GB/T 28592-2012）七级分档，取各级中值；
  4) 物理公式：Qout(t) = K1 * Qout(t-1) + (P1+P2+P3+P4)/4 * S，流域面积 S = 1477；
  5) 未来的 Qout(t) 使用上一次的预测值（自回归，不用真值）。

量纲说明（很关键）：
  降水单位 mm/d，流域面积 km²，径流 Qout 单位 m³/s。
  (P1+P2+P3+P4)/4 * S 直接相乘得到的是 "mm/d · km²"，与 Qout(=30 m³/s 量级)
  差一个换算系数。因此把该系数并入降水项系数 C：
        Qout(t) = K1 * Qout(t-1) + C * (P1+P2+P3+P4)/4 * S
  纯单位换算时 C0 = 1/86.4 = 0.011574（mm/d·km² -> m³/s）。
  C 由模型识别，并可反推物理上可解释的径流系数：
        C = (1 - K1) * Rc / 86.4    =>    Rc = 86.4 * C / (1 - K1)

运行：
  python lstm_pinn_forecast.py --data basin2_input_2013_2025.xlsx --epochs 260
"""

import argparse
import copy
import json
import math
import os
import random
import sys
import time

import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    HAS_MPL = True
except Exception:  # pragma: no cover
    HAS_MPL = False

# 中文 Windows 的控制台是 GBK；必须在 argparse 打印中文帮助之前就把标准流切成 UTF-8，
# 否则 --help / 报错信息会抛 UnicodeEncodeError。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # pragma: no cover
    pass


# --------------------------------------------------------------------------------------
# 国标 GB/T 28592-2012 降水量等级（24h）：七级分档 + 各级中值
# --------------------------------------------------------------------------------------
# 国标 GB/T 28592-2012《降水量等级》24 小时雨量分级（七级），中值取各级上下限的算术平均
PRECIP_TIERS = [
    ("Ⅰ", "无雨/微量", 0.0, 0.1, 0.05),        # <0.1
    ("Ⅱ", "小雨", 0.1, 9.9, 5.00),             # 0.1 ~ 9.9
    ("Ⅲ", "中雨", 10.0, 24.9, 17.45),          # 10.0 ~ 24.9
    ("Ⅳ", "大雨", 25.0, 49.9, 37.45),          # 25.0 ~ 49.9
    ("Ⅴ", "暴雨", 50.0, 99.9, 74.95),          # 50.0 ~ 99.9
    ("Ⅵ", "大暴雨", 100.0, 249.9, 174.95),     # 100.0 ~ 249.9
    ("Ⅶ", "特大暴雨", 250.0, 550.0, 300.00),   # >=250.0（上限开口，取 300 作代表值）
]
TIER_MIDS = np.array([t[4] for t in PRECIP_TIERS], dtype=float)


def tier_index(p):
    """按国标把日降水量映射到 0..6 档。"""
    p = np.atleast_1d(np.asarray(p, dtype=float))
    idx = np.zeros(p.shape, dtype=int)
    for b in np.array([t[2] for t in PRECIP_TIERS[1:]], dtype=float):
        idx += (p >= b).astype(int)
    return idx


# --------------------------------------------------------------------------------------
# 数据
# --------------------------------------------------------------------------------------
N_ST = 6
COL_QOUT, COL_EVAP = 1, 2
COL_P = {3: "p1", 4: "p2", 5: "p3", 6: "p4", 7: "p5", 8: "p6"}


def load_frame(path, sheet="Sheet1"):
    raw = pd.read_excel(path, sheet_name=sheet, header=None)
    d = pd.DataFrame()
    d["date"] = pd.to_datetime(raw.iloc[1:, 0], errors="coerce").values
    d["q"] = pd.to_numeric(raw.iloc[1:, COL_QOUT], errors="coerce").values
    d["evap"] = pd.to_numeric(raw.iloc[1:, COL_EVAP], errors="coerce").values
    for c, nm in COL_P.items():
        d[nm] = pd.to_numeric(raw.iloc[1:, c], errors="coerce").values
    d = d.dropna(subset=["date"]).sort_values("date").set_index("date")
    d = d.reindex(pd.date_range(d.index.min(), d.index.max(), freq="D"))
    d["q"] = d["q"].interpolate(limit_direction="both")
    for c in ["evap"] + list(COL_P.values()):
        d[c] = d[c].interpolate(limit_direction="both").fillna(0.0)
    df = d
    df["pmean"] = df[[v for v in COL_P.values()]].mean(axis=1)
    return df


def make_features(df):
    q = df["q"].to_numpy(float)
    pmean = df["pmean"].to_numpy(float)
    evap = df["evap"].to_numpy(float)
    _st = ["p%d" % (i + 1) for i in range(N_ST)]
    ps = [df[c].to_numpy(float) for c in _st]
    doy = df.index.dayofyear.to_numpy(float)

    s = {
        "q": float(np.log1p(np.nanmax(q))),
        "p": float(np.log1p(np.nanmax(pmean))),
        "e": float(np.log1p(np.nanmax(evap))),
        "ps": [float(np.log1p(np.nanmax(x))) for x in ps],
    }
    feat = np.zeros((len(df), 3 + N_ST + 2), dtype=np.float32)
    feat[:, 0] = np.log1p(q) / max(s["q"], 1e-6)
    feat[:, 1] = np.log1p(pmean) / max(s["p"], 1e-6)
    feat[:, 2] = np.log1p(evap) / max(s["e"], 1e-6)
    for i in range(N_ST):
        feat[:, 3 + i] = np.log1p(ps[i]) / max(s["ps"][i], 1e-6)
    feat[:, 3 + N_ST] = np.sin(2 * np.pi * doy / 365.25)
    feat[:, 3 + N_ST + 1] = np.cos(2 * np.pi * doy / 365.25)
    return feat, s, doy


def doy_embed(doy_arr):
    return np.stack([np.sin(2 * np.pi * np.asarray(doy_arr, float) / 365.25),
                     np.cos(2 * np.pi * np.asarray(doy_arr, float) / 365.25)],
                    axis=-1).astype(np.float32)


def build_dataset(df, window, horizon, feat, scales, doy):
    q = df["q"].to_numpy(float)
    pmean = df["pmean"].to_numpy(float)
    T = len(df)
    origins = np.arange(window - 1, T - horizon)

    Xh = np.stack([feat[t - window + 1: t + 1] for t in origins])
    pfut_raw = np.stack([pmean[t + 1: t + 1 + horizon] for t in origins])
    y = np.stack([q[t + 1: t + 1 + horizon] for t in origins])
    q0 = np.array([q[t] for t in origins], dtype=float)
    p_last = np.array([pmean[t] for t in origins], dtype=float)
    doyf = np.stack([doy[t + 1: t + 1 + horizon] for t in origins])

    return dict(
        Xh=torch.from_numpy(Xh),
        pfut_norm=torch.from_numpy((np.log1p(pfut_raw) / max(scales["p"], 1e-6)).astype(np.float32)),
        pfut_raw=torch.from_numpy(pfut_raw.astype(np.float32)),
        doyfut=torch.from_numpy(doy_embed(doyf)),
        q0=torch.from_numpy(q0.astype(np.float32)),
        p_last=torch.from_numpy(p_last.astype(np.float32)),
        p_last_np=p_last,
        y=torch.from_numpy(y.astype(np.float32)),
        y_np=y, pfut_raw_np=pfut_raw, q0_np=q0,
        dates=df.index[origins], scales=scales,
        feat_all=feat, doy_all=doy, q_all=q, pmean_all=pmean,
        n_feat=feat.shape[1],
    )


# --------------------------------------------------------------------------------------
# LSTM-PINN
# --------------------------------------------------------------------------------------
class LSTMPINN(nn.Module):
    """
    编码器：60 天历史 -> LSTM 隐状态
    解码器：7 步 GRUCell，每步给出物理参数与残差修正 delta_t

    physics="c"  用户原式（系数形式）：Q(t) = K1_t·Q(t-1) + C_t·Pbar(t)·S
    physics="lr" 线性水库标准形式：    Q(t) = K1_t·Q(t-1) + (1-K1_t)·Rc_t·Pbar(t)·S/86.4
                 等价于把 C_t 约束为 (1-K1_t)·Rc_t/86.4，让降水项"当日起效"。
    p_lag=True   二参数单位线（总量守恒，只把产流在时间上前后分配）：
                 Q(t) = K1·Q(t-1) + C·[(1-a)·Pbar(t) + a·Pbar(t-1)]·S , a∈(0,1)
                 用上暴雨日的滞后效应（本流域洪峰常滞后雨量一天）。
    残差修正：Q(t) <- Q(t)·exp(delta_t)，|delta| <= delta_scale
    自回归：Q(t-1) 第 1 步用最后一个实测值，之后用上一步的预测值。
    """

    def __init__(self, n_feat=9, hidden=64, layers=2, dropout=0.15,
                 area=1477.0, k1_init=0.92, c_init=5.85e-4,
                 delta_scale=0.15, q_scale=7.6, physics="c", rc_init=0.40,
                 logc_max=-3.0, p_lag=False, c2_init=1.2e-4):
        super().__init__()
        self.enc = nn.LSTM(n_feat, hidden, num_layers=layers, batch_first=True,
                           dropout=dropout if layers > 1 else 0.0)
        self.dec = nn.GRUCell(4, hidden)
        self.h2k = nn.Linear(hidden, 1)
        self.h2c = nn.Linear(hidden, 1)
        self.h2d = nn.Linear(hidden, 1)
        nn.init.zeros_(self.h2k.weight)
        nn.init.constant_(self.h2k.bias, float(math.log(k1_init / (1.0 - k1_init))))
        nn.init.zeros_(self.h2c.weight)
        if physics == "lr":
            nn.init.constant_(self.h2c.bias, float(math.log(rc_init / (1.0 - rc_init))))
        else:
            nn.init.constant_(self.h2c.bias, float(math.log(c_init)))
        self.p_lag = bool(p_lag)
        if self.p_lag:
            # 单位线形状参数 a：当天权重 (1-a)、前一天权重 a，两者之和恒为 1
            self.h2a = nn.Linear(hidden, 1)
            nn.init.zeros_(self.h2a.weight)
            nn.init.constant_(self.h2a.bias, float(math.log((1.0 - c2_init) / c2_init))
                              if 0.0 < c2_init < 1.0 else 0.0)
        nn.init.zeros_(self.h2d.weight)
        nn.init.constant_(self.h2d.bias, 0.0)
        self.area = float(area)
        self.delta_scale = float(delta_scale)
        self.q_scale = float(q_scale)
        self.physics = physics
        self.logc_max = float(logc_max)

    def forward(self, xh, pfut_norm, pfut_raw, doyfut, q0, pprev=None):
        _, (hn, _) = self.enc(xh)
        h = hn[-1]
        q_prev = q0
        qs, k1s, cs, ds, rcs, c2s = [], [], [], [], [], []
        for k in range(pfut_norm.shape[1]):
            qn = torch.log1p(q_prev.clamp_min(1e-6)) / self.q_scale
            inp = torch.stack([qn, pfut_norm[:, k], doyfut[:, k, 0], doyfut[:, k, 1]], dim=-1)
            h = self.dec(inp, h)
            k1 = torch.sigmoid(self.h2k(h)).squeeze(-1)
            if self.physics == "lr":
                rc = torch.sigmoid(self.h2c(h)).squeeze(-1)      # 径流系数 (0,1)
                c = (1.0 - k1) * rc / 86.4
            else:
                c = torch.exp(self.h2c(h).squeeze(-1).clamp(-25.0, self.logc_max))
                rc = 86.4 * c / (1.0 - k1).clamp_min(1e-4)
            d = torch.tanh(self.h2d(h).squeeze(-1)) * self.delta_scale
            if self.p_lag:
                a_lag = torch.sigmoid(self.h2a(h)).squeeze(-1)
                pbar = (1.0 - a_lag) * pfut_raw[:, k] + a_lag * pprev[:, k]
                c2s.append(a_lag)
            else:
                pbar = pfut_raw[:, k]
            q_phys = k1 * q_prev + c * pbar * self.area
            q_prev = q_phys * torch.exp(d)
            qs.append(q_prev); k1s.append(k1); cs.append(c); ds.append(d); rcs.append(rc)
        out = dict(q=torch.stack(qs, 1), k1=torch.stack(k1s, 1),
                   c=torch.stack(cs, 1), delta=torch.stack(ds, 1),
                   rc=torch.stack(rcs, 1))
        out["a_lag"] = torch.stack(c2s, 1) if self.p_lag else torch.zeros_like(out["c"])
        return out


# --------------------------------------------------------------------------------------
# 训练 / 推演
# --------------------------------------------------------------------------------------
def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)


def lead_weights(H):
    w = 1.0 / np.sqrt(np.arange(1, H + 1, dtype=float))
    return torch.tensor(w / w.mean(), dtype=torch.float32)


def composite_loss(out, y, w, q_ref, args):
    pl = torch.log1p(out["q"].clamp_min(1e-6))
    tl_ = torch.log1p(y.clamp_min(1e-6))
    log_loss = (F.smooth_l1_loss(pl, tl_, beta=0.05, reduction="none") * w).mean()
    if getattr(args, "loss_l2", False):
        # 与 NSE 口径一致：线性空间的平方误差
        lin_loss = (((out["q"] - y) / q_ref) ** 2 * w).mean()
    else:
        lin_loss = (F.smooth_l1_loss(out["q"] / q_ref, y / q_ref, beta=0.20,
                                     reduction="none") * w).mean()
    ld = (1.0 - args.loss_mix) * log_loss + args.loss_mix * lin_loss
    loss = ld + args.lam_res * (out["delta"] ** 2).mean()
    loss = loss + args.lam_prior * ((out["k1"] - args.k1_prior) ** 2).mean()
    if args.horizon > 1:
        loss = loss + args.lam_smooth * ((out["k1"][:, 1:] - out["k1"][:, :-1]) ** 2).mean()
    return loss, ld


def _pprev(ds, idx):
    """第 k 步的“前一天面雨量”：第 1 步用起报日实测，之后用上一步的未来降水。"""
    pb = ds["pfut_raw_np"][idx]
    pl = ds["p_last_np"][idx]
    if pb.shape[1] > 1:
        return torch.from_numpy(np.concatenate([pl[:, None], pb[:, :-1]], axis=1).astype(np.float32))
    return torch.from_numpy(pl[:, None].astype(np.float32))

def train_model(ds, tr, va, args, log_rows):
    w = lead_weights(args.horizon)
    net = LSTMPINN(n_feat=ds["n_feat"], hidden=args.hidden, layers=args.layers,
                   dropout=args.dropout, area=args.area,
                   k1_init=args.k1_init, c_init=args.c_init,
                   delta_scale=args.delta_scale, q_scale=ds["scales"]["q"],
                   physics=args.physics, rc_init=args.rc_init,
                   logc_max=args.logc_max, p_lag=args.p_lag, c2_init=args.c2_init)
    q_ref = torch.tensor(float(max(ds["y_np"][tr].mean(), 1e-3)), dtype=torch.float32)
    opt = torch.optim.AdamW(net.parameters(), lr=args.lr, weight_decay=args.wd)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="min", factor=0.5,
                                                       patience=10, min_lr=1e-5)
    best, best_state, bad, t0 = float("inf"), None, 0, time.time()
    nb = int(math.ceil(len(tr) / args.batch))

    for ep in range(1, args.epochs + 1):
        net.train()
        perm = np.random.permutation(tr)
        tl = 0.0
        for b in range(nb):
            idx = perm[b * args.batch:(b + 1) * args.batch]
            if len(idx) < 2:
                continue
            it = torch.from_numpy(idx)
            out = net(ds["Xh"][it], ds["pfut_norm"][it], ds["pfut_raw"][it],
                      ds["doyfut"][it], ds["q0"][it], _pprev(ds, it.numpy()))
            loss, ld = composite_loss(out, ds["y"][it], w, q_ref, args)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
            opt.step()
            tl += float(ld.detach()) * len(idx)
        tl /= max(len(tr), 1)

        net.eval()
        vl = 0.0
        with torch.no_grad():
            for b in range(0, len(va), 256):
                idx = va[b:b + 256]
                it = torch.from_numpy(idx)
                out = net(ds["Xh"][it], ds["pfut_norm"][it], ds["pfut_raw"][it],
                          ds["doyfut"][it], ds["q0"][it], _pprev(ds, idx))
                _, ld = composite_loss(out, ds["y"][it], w, q_ref, args)
                vl += float(ld) * len(idx)
        vl /= max(len(va), 1)
        sched.step(vl)
        log_rows.append({"epoch": ep, "train_loss": round(tl, 6), "val_loss": round(vl, 6),
                         "lr": opt.param_groups[0]["lr"]})
        if vl < best - 1e-6:
            best, best_state, bad = vl, copy.deepcopy(net.state_dict()), 0
        else:
            bad += 1
        if ep % 10 == 0 or ep == 1:
            print("  ep %3d  train %.5f  val %.5f  lr %.2e  best %.5f  (%.0fs)"
                  % (ep, tl, vl, opt.param_groups[0]["lr"], best, time.time() - t0), flush=True)
        if bad >= args.patience:
            print("  早停于第 %d 轮（最优 val=%.5f）" % (ep, best), flush=True)
            break
    if best_state is not None:
        net.load_state_dict(best_state)
    net.eval()
    return net, best


@torch.no_grad()
def rollout(nets, Xh, q0, doyfut, p_raw_np, p_scale, p_last_np=None):
    """统一推演入口：nets 可以是单个模型或模型列表（多种子集成取平均）。
    Xh(N,W,F) q0(N,) doyfut(N,H,2) p_raw_np(N,H) 未来降水; p_last_np(N,) 起报日面雨量
    -> (q,k1,c,delta,rc)"""
    if not isinstance(nets, (list, tuple)):
        nets = [nets]
    if p_last_np is None:
        p_last_np = np.zeros(len(p_raw_np))
    p_last_np = np.asarray(p_last_np, dtype=float).reshape(-1)
    acc_q, acc_k1, acc_c, acc_d, acc_rc = [], [], [], [], []
    for net in nets:
        oq, ok1, oc, od, orc = [], [], [], [], []
        n = Xh.shape[0]
        for b in range(0, n, 256):
            xb = Xh[b:b + 256]
            pb = p_raw_np[b:b + 256].astype(np.float32)
            pn = (np.log1p(pb) / max(p_scale, 1e-6)).astype(np.float32)
            pl = p_last_np[b:b + 256]
            # 第 k 步的“前一天面雨量”：第 1 步用起报日实测，之后用上一步的未来降水
            pprev = np.concatenate([pl[:, None], pb[:, :-1]], axis=1) if pb.shape[1] > 1 else pl[:, None]
            o = net(xb, torch.from_numpy(pn), torch.from_numpy(pb),
                    doyfut[b:b + 256], q0[b:b + 256], torch.from_numpy(pprev.astype(np.float32)))
            oq.append(o["q"].numpy()); ok1.append(o["k1"].numpy())
            oc.append(o["c"].numpy()); od.append(o["delta"].numpy())
            orc.append(o["rc"].numpy())
        acc_q.append(np.concatenate(oq)); acc_k1.append(np.concatenate(ok1))
        acc_c.append(np.concatenate(oc)); acc_d.append(np.concatenate(od))
        acc_rc.append(np.concatenate(orc))
    return (np.mean(acc_q, 0), np.mean(acc_k1, 0), np.mean(acc_c, 0),
            np.mean(acc_d, 0), np.mean(acc_rc, 0))


def rollout_idx(net, ds, idx, p_raw_np=None):
    it = torch.from_numpy(np.asarray(idx))
    p = ds["pfut_raw_np"][idx] if p_raw_np is None else np.asarray(p_raw_np, dtype=float)
    p = np.atleast_2d(p)
    if p.shape[0] != len(np.asarray(idx)):
        p = p.reshape(len(np.asarray(idx)), -1)
    return rollout(net, ds["Xh"][it], ds["q0"][it], ds["doyfut"][it], p,
                   ds["scales"]["p"], ds["p_last_np"][idx])


def rollout_window(net, ds, feat_win, q_last, doy_future, p_raw, p_last=0.0):
    """单样本推演：feat_win(W,F) 历史窗口；p_raw(H,) 未来降水；p_last 起报日面雨量。"""
    X = torch.from_numpy(feat_win[None].astype(np.float32))
    q0 = torch.tensor([float(q_last)], dtype=torch.float32)
    d = torch.from_numpy(doy_embed(doy_future)[None])
    return rollout(net, X, q0, d, np.asarray(p_raw, float)[None],
                   ds["scales"]["p"], np.array([float(p_last)]))


# --------------------------------------------------------------------------------------
# 指标 / 率定
# --------------------------------------------------------------------------------------
def metrics(obs, sim):
    obs = np.asarray(obs, float); sim = np.asarray(sim, float)
    m = np.isfinite(obs) & np.isfinite(sim)
    obs, sim = obs[m], sim[m]
    if obs.size < 2:
        return dict(n=0, NSE=np.nan, NSE_log=np.nan, RMSE=np.nan, MAE=np.nan,
                    PBIAS=np.nan, R=np.nan, KGE=np.nan)
    r = sim - obs
    sst = float(np.sum((obs - obs.mean()) ** 2))
    sse = float(np.sum(r ** 2))
    nse = 1 - sse / sst if sst > 0 else np.nan
    # 对数空间 NSE：压制极值样本的主导作用，反映相对量级上的技巧
    lo, ls = np.log1p(np.clip(obs, 1e-6, None)), np.log1p(np.clip(sim, 1e-6, None))
    sst_l = float(np.sum((lo - lo.mean()) ** 2))
    nse_log = 1 - float(np.sum((ls - lo) ** 2)) / sst_l if sst_l > 0 else np.nan
    cc = float(np.corrcoef(obs, sim)[0, 1]) if obs.std() > 0 and sim.std() > 0 else np.nan
    alpha = float(sim.std() / obs.std()) if obs.std() > 0 else np.nan
    beta = float(sim.mean() / obs.mean()) if obs.mean() != 0 else np.nan
    kge = (1 - math.sqrt((cc - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2)
           if all(np.isfinite([cc, alpha, beta])) else np.nan)
    return dict(n=int(obs.size), NSE=float(nse), NSE_log=float(nse_log),
                RMSE=math.sqrt(sse / obs.size), MAE=float(np.mean(np.abs(r))),
                PBIAS=float(100.0 * r.sum() / obs.sum()) if obs.sum() != 0 else np.nan,
                R=cc, KGE=float(kge))


def calibrate_physics(q, pmean, area):
    """率定 Q(t)=K1*Q(t-1)+C*Pbar(t)*S 两参数（1 步递推、对数空间最小二乘 2D 网格）。"""
    tgt = np.clip(q[1:], 1e-6, None)
    prev = q[:-1]
    pin = pmean[1:] * area
    ylog = np.log1p(tgt)
    best = (np.inf, 0.9, 1e-4)
    for k1 in np.arange(0.50, 0.9990, 0.0025):
        base = k1 * prev
        for c in np.logspace(-6.0, -1.8, 160):
            sim = np.log1p(np.clip(base + c * pin, 1e-6, None))
            e = float(np.mean((sim - ylog) ** 2))
            if e < best[0]:
                best = (e, float(k1), float(c))
    return best[1], best[2]


# --------------------------------------------------------------------------------------
# 绘图
# --------------------------------------------------------------------------------------
def save_fig(fig, path):
    if not HAS_MPL:
        return
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_losses(log_df, path):
    if not HAS_MPL or log_df.empty:
        return
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(log_df.epoch, log_df.train_loss, label="训练损失")
    ax.plot(log_df.epoch, log_df.val_loss, label="验证损失")
    ax.set_xlabel("轮次 (epoch)"); ax.set_ylabel("损失（对数空间）")
    ax.set_title("LSTM-PINN 训练过程"); ax.legend(); ax.grid(alpha=.3)
    save_fig(fig, path)


def plot_metrics(met_df, path, title):
    if not HAS_MPL or met_df.empty:
        return
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    for ax, col in zip(axes, ["NSE", "RMSE", "MAE"]):
        for name, g in met_df.groupby("model", sort=False):
            ax.plot(g["lead"], g[col], marker="o", ms=3, label=name)
        ax.set_xlabel("预见期 (天)"); ax.set_ylabel(col); ax.set_title(col); ax.grid(alpha=.3)
    axes[0].legend(fontsize=8)
    fig.suptitle(title)
    save_fig(fig, path)


def plot_series(dates, obs, pred1, path, title, n=400):
    if not HAS_MPL:
        return
    fig, ax = plt.subplots(figsize=(12, 4))
    ax.plot(dates[-n:], obs[-n:], lw=1.0, label="实测 Qout")
    ax.plot(dates[-n:], pred1[-n:], lw=1.0, alpha=.85, label="预报（1 天预见期）")
    ax.set_ylabel("Qout (m³/s)"); ax.set_title(title); ax.legend(); ax.grid(alpha=.3)
    fig.autofmt_xdate()
    save_fig(fig, path)


def plot_scatter(obs, sim, path, title):
    if not HAS_MPL:
        return
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.scatter(obs, sim, s=5, alpha=.4)
    lo = max(1e-2, min(obs.min(), sim.min()) * .8); hi = max(obs.max(), sim.max()) * 1.1
    ax.plot([lo, hi], [lo, hi], "k--", lw=1)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("实测 Qout (m³/s)"); ax.set_ylabel("预报 Qout (m³/s)")
    ax.set_title(title); ax.grid(alpha=.3, which="both")
    save_fig(fig, path)


def plot_scenarios(scen, fdates, q_last, path):
    if not HAS_MPL:
        return
    fig, ax = plt.subplots(figsize=(10, 5))
    for name, row in scen.iterrows():
        ax.plot(fdates, row.values, marker="o", ms=4, label=name)
    ax.axhline(q_last, ls=":", c="k", lw=1, label="起报日实测 %.2f m³/s" % q_last)
    ax.set_yscale("log")
    ax.set_ylabel("Qout (m³/s，对数轴)"); ax.set_xlabel("预报日期")
    ax.set_title("7 天逐日自回归预报：国标七级降水情景")
    ax.legend(fontsize=7, ncol=2); ax.grid(alpha=.3, which="both")
    fig.autofmt_xdate()
    save_fig(fig, path)


def plot_params(dates, k1, rc, path):
    if not HAS_MPL:
        return
    fig, axes = plt.subplots(2, 1, figsize=(11, 6), sharex=True)
    axes[0].plot(dates, k1, lw=1, color="C0")
    axes[0].set_ylabel("K1（退水系数）"); axes[0].grid(alpha=.3)
    axes[0].set_title("物理参数识别结果（1 天预见期）")
    axes[1].plot(dates, rc, lw=1, color="C1")
    axes[1].set_ylabel("隐含径流系数 Rc"); axes[1].set_xlabel("日期"); axes[1].grid(alpha=.3)
    fig.autofmt_xdate()
    save_fig(fig, path)


# --------------------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="LSTM-PINN 7 天逐日自回归径流预报")
    ap.add_argument("--data", default=r"C:\Users\10792\PycharmProjects\PythonProject1\output.xlsx")
    ap.add_argument("--sheet", default="Sheet1")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--area", type=float, default=4013.0, help="流域面积 S (km²)")
    ap.add_argument("--physics", choices=["c", "lr"], default="c",
                    help="c=用户原式系数形式; lr=线性水库标准形式 Q=K1*Qprev+(1-K1)*Rc*P*S/86.4")
    ap.add_argument("--rc-init", type=float, default=0.40, help="lr 形式的径流系数初值")
    ap.add_argument("--logc-max", type=float, default=-3.0,
                    help="c 形式下 C 的上限（自然对数），-3 -> 0.0498")
    ap.add_argument("--train-tier", action="store_true",
                    help="训练时未来降水也用分档代表值（与推理口径一致）")
    ap.add_argument("--p-lag", action="store_true",
                    help="物理式中增加滞后一天降水项：Q=K1*Qprev+C1*P(t)*S+C2*P(t-1)*S")
    ap.add_argument("--c2-init", type=float, default=0.30, help="单位线滞后权重 a 初值(0~1)")
    ap.add_argument("--tier-mode", choices=["mid", "mean"], default="mean",
                    help="分档代表值：mid=各级中值；mean=各级条件期望(用训练期统计)")
    ap.add_argument("--window", type=int, default=60, help="历史样本长度")
    ap.add_argument("--horizon", type=int, default=7, help="预见期天数")
    ap.add_argument("--hidden", type=int, default=96)
    ap.add_argument("--layers", type=int, default=2)
    ap.add_argument("--dropout", type=float, default=0.2)
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--lr", type=float, default=1.5e-3)
    ap.add_argument("--wd", type=float, default=1e-4)
    ap.add_argument("--patience", type=int, default=60)
    ap.add_argument("--k1-init", type=float, default=0.92)
    ap.add_argument("--c-init", type=float, default=5.85e-4)
    ap.add_argument("--k1-prior", type=float, default=0.90, help="K1 物理先验中心")
    ap.add_argument("--delta-scale", type=float, default=0.30, help="残差修正幅度上限")
    ap.add_argument("--lam-res", type=float, default=0.5, help="物理残差惩罚权重")
    ap.add_argument("--lam-prior", type=float, default=1e-3, help="K1 先验权重")
    ap.add_argument("--lam-smooth", type=float, default=1e-2, help="参数平滑权重")
    ap.add_argument("--loss-mix", type=float, default=0.5,
                    help="线性空间损失占比(0=纯对数空间,1=纯线性空间)")
    ap.add_argument("--loss-l2", action="store_true",
                    help="线性部分改用平方误差（与 NSE 口径一致）")
    ap.add_argument("--train-end", default="2021-12-31")
    ap.add_argument("--val-end", default="2023-12-31")
    ap.add_argument("--n-models", type=int, default=4,
                    help="多种子集成的模型个数（4 个约 4 倍训练时间，最稳）")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    global TIER_MIDS
    set_seed(args.seed)
    torch.set_num_threads(max(1, min(8, os.cpu_count() or 4)))
    os.makedirs(args.out, exist_ok=True)
    figdir = os.path.join(args.out, "figures")
    os.makedirs(figdir, exist_ok=True)

    # 控制台可能是 GBK，统一转 UTF-8，并把全部输出同时写入日志文件
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    orig_out = sys.stdout
    logf = open(os.path.join(args.out, "run_log.txt"), "w", encoding="utf-8")

    class _Tee:
        def write(self, s):
            logf.write(s)
            logf.flush()
            try:
                orig_out.write(s)
                orig_out.flush()
            except Exception:
                pass

        def flush(self):
            logf.flush()

    sys.stdout = _Tee()

    print("=" * 78, flush=True)
    print("LSTM-PINN 7 天逐日自回归径流预报", flush=True)
    print("=" * 78, flush=True)

    df = load_frame(args.data, args.sheet)
    print("数据：%s ~ %s，共 %d 天" % (df.index[0].date(), df.index[-1].date(), len(df)), flush=True)
    print("Qout: min %.2f  mean %.2f  max %.2f m³/s"
          % (df.q.min(), df.q.mean(), df.q.max()), flush=True)

    feat, scales, doy = make_features(df)
    ds = build_dataset(df, args.window, args.horizon, feat, scales, doy)
    dates = ds["dates"]
    gap = 60
    _o = np.arange(args.window - 1, len(df) - args.horizon)
    n_tr, n_va, n_te = 5302, 1467, 580
    _i0 = args.window - 1
    _a = _i0 + n_tr
    _b = _a + gap
    _c = _b + n_va
    _d = _c + gap
    tr = np.where(_o < _a)[0]
    va = np.where((_o >= _b) & (_o < _c))[0]
    te = np.where((_o >= _d) & (_o < _d + n_te))[0]
    dates = df.index[_o]
    print("样本：训练 %d / 验证 %d / 测试 %d（共 %d）"
          % (len(tr), len(va), len(te), len(ds["y"])), flush=True)
    print("物理公式：Q(t) = K1*Q(t-1) + C*(P1+P2+P3+P4)/4*S,  S = %.0f km²" % args.area, flush=True)
    if args.p_lag:
        print("物理式扩展：增加滞后一天降水项 C2*(P1+P2+P3+P4)/4(t-1)*S", flush=True)

    # 分档代表值：中值 或 该档条件期望（用训练期实测降水统计，不碰测试期）
    if args.tier_mode == "mean":
        _pv = df.pmean.to_numpy(float)[np.asarray(df.index <= pd.Timestamp(args.train_end))]
        _ti = tier_index(_pv)
        _vals = np.array([_pv[_ti == i].mean() if (_ti == i).sum() >= 5 else TIER_MIDS[i]
                          for i in range(len(PRECIP_TIERS))])
        TIER_MIDS = _vals
        print("分档代表值 = 条件期望(mm)：%s" % np.round(_vals, 3), flush=True)
        print("            （训练期各级样本数：%s）"
              % np.bincount(_ti, minlength=len(PRECIP_TIERS)), flush=True)

    if args.train_tier:
        # 训练与推理口径一致：未来降水一律先分档、再取中值
        qp = TIER_MIDS[tier_index(ds["pfut_raw_np"])]
        ds["pfut_raw"] = torch.from_numpy(qp.astype(np.float32))
        ds["pfut_norm"] = torch.from_numpy(
            (np.log1p(qp) / max(scales["p"], 1e-6)).astype(np.float32))
        ds["pfut_raw_np"] = qp
        print("未来降水：训练与推理均使用国标分档中值", flush=True)

    tmask = np.asarray(df.index <= pd.Timestamp(args.train_end))
    k1c, cc = calibrate_physics(df.q.to_numpy(float)[tmask],
                                df.pmean.to_numpy(float)[tmask], args.area)
    rc = 86.4 * cc / max(1 - k1c, 1e-6)
    print("纯物理率定：K1 = %.4f，C = %.6f，隐含径流系数 Rc = %.3f" % (k1c, cc, rc), flush=True)

    print("-" * 78, flush=True)
    print("开始训练 LSTM-PINN（%d 个模型集成）..." % max(1, args.n_models), flush=True)
    log_rows, nets, best_vals, seeds = [], [], [], []
    for i in range(max(1, args.n_models)):
        sd = args.seed + i * 1000
        seeds.append(sd)
        set_seed(sd)
        print("  ── 模型 %d/%d  seed=%d" % (i + 1, max(1, args.n_models), sd), flush=True)
        rows_i = []
        net_i, bv_i = train_model(ds, tr, va, args, rows_i)
        for r in rows_i:
            r["model"] = i + 1
            r["seed"] = sd
        log_rows.extend(rows_i)
        nets.append(net_i)
        best_vals.append(bv_i)
    best_val = float(min(best_vals))
    log_df = pd.DataFrame(log_rows)
    log_df.to_csv(os.path.join(args.out, "training_log.csv"), index=False, encoding="utf-8-sig")
    torch.save([n.state_dict() for n in nets], os.path.join(args.out, "lstm_pinn.pt"))
    print("  各模型最优验证损失：%s" % ", ".join("%.5f" % v for v in best_vals), flush=True)

    # ---------------- 验证集（超参选择口径，不碰测试集） ----------------
    p_tier_va = TIER_MIDS[tier_index(ds["pfut_raw_np"][va])]
    pv, *_ = rollout_idx(nets, ds, va, p_raw_np=p_tier_va)
    mv = metrics(ds["y_np"][va].ravel(), pv.ravel())
    print("验证集（分档中值降水，7 天合并）：NSE = %.4f  NSE_log = %.4f  RMSE = %.2f  KGE = %.3f"
          % (mv["NSE"], mv["NSE_log"], mv["RMSE"], mv["KGE"]), flush=True)

    # ---------------- 测试集：未来降水统一按国标七级分档取中值 ----------------
    print("-" * 78, flush=True)
    print("测试集（2024-01-01 起）评估：未来降水一律按国标七级分档取中值 ...", flush=True)
    y_te = ds["y_np"][te]
    q0_te = ds["q0_np"][te]
    pf_te = ds["pfut_raw_np"][te]
    d_te = dates[te]

    # 预报用降水：把每天的实际降水量按国标分档，取该档中值作为输入
    tier_mid_te = TIER_MIDS[tier_index(pf_te)]
    pred_q, pred_k1, pred_c, pred_d, pred_rc = rollout_idx(nets, ds, te, p_raw_np=tier_mid_te)

    persist = np.repeat(q0_te[:, None], args.horizon, axis=1)
    phys = np.zeros_like(y_te)
    prev = q0_te.copy()
    for k in range(args.horizon):
        prev = k1c * prev + cc * tier_mid_te[:, k] * args.area
        phys[:, k] = prev

    _mlab = ("LSTM-PINN（七级分档中值降水）" if args.tier_mode == "mid"
             else "LSTM-PINN（七级分档条件期望降水）")
    models = [(_mlab, pred_q),
              ("纯物理公式（率定 K1/C，同口径降水）", phys),
              ("持续性预报", persist)]

    rows = []
    for k in range(args.horizon):
        for name, arr in models:
            rows.append(dict(model=name, lead=k + 1, **metrics(y_te[:, k], arr[:, k])))
    met = pd.DataFrame(rows)
    met.to_csv(os.path.join(args.out, "metrics_by_lead.csv"), index=False, encoding="utf-8-sig")

    print("逐预见期 NSE（测试集）：", flush=True)
    print(met.pivot_table(index="lead", columns="model", values="NSE").round(3).to_string(), flush=True)
    print("-" * 78, flush=True)
    print("逐预见期 RMSE（测试集）：", flush=True)
    print(met.pivot_table(index="lead", columns="model", values="RMSE").round(2).to_string(), flush=True)

    allrow = []
    for name, arr in models:
        m = metrics(y_te.ravel(), arr.ravel()); m["model"] = name
        allrow.append(m)
    met_all = pd.DataFrame(allrow)[["model", "n", "NSE", "NSE_log", "RMSE", "MAE",
                                    "PBIAS", "R", "KGE"]]
    met_all.to_csv(os.path.join(args.out, "metrics_overall.csv"), index=False, encoding="utf-8-sig")
    print("-" * 78, flush=True)
    print("7 天合并指标：", flush=True)
    print(met_all.round(4).to_string(index=False), flush=True)
    print("-" * 78, flush=True)
    print("逐预见期 NSE（对数空间，压制极值样本影响）：", flush=True)
    print(met.pivot_table(index="lead", columns="model", values="NSE_log").round(3).to_string(), flush=True)

    ser = pd.DataFrame({"date": d_te.strftime("%Y-%m-%d"), "Q0": q0_te})
    for k in range(args.horizon):
        ser["obs_d+%d" % (k + 1)] = y_te[:, k]
        ser["P_tier_d+%d" % (k + 1)] = np.round(tier_mid_te[:, k], 2)
        ser["pred_d+%d" % (k + 1)] = np.round(pred_q[:, k], 3)
    ser["K1_d+1"] = np.round(pred_k1[:, 0], 5)
    ser["C_d+1"] = np.round(pred_c[:, 0], 8)
    ser["Rc_d+1"] = np.round(pred_rc[:, 0], 4)
    ser.to_csv(os.path.join(args.out, "test_series_forecasts.csv"), index=False, encoding="utf-8-sig")

    par = pd.DataFrame({
        "lead": np.arange(1, args.horizon + 1),
        "K1_mean": np.round(pred_k1.mean(0), 4),
        "K1_p05": np.round(np.percentile(pred_k1, 5, axis=0), 4),
        "K1_p95": np.round(np.percentile(pred_k1, 95, axis=0), 4),
        "C_mean": np.round(pred_c.mean(0), 6),
        "Rc_mean": np.round(pred_rc.mean(0), 4),
        "Rc_p05": np.round(np.percentile(pred_rc, 5, axis=0), 4),
        "Rc_p95": np.round(np.percentile(pred_rc, 95, axis=0), 4),
    })
    par.to_csv(os.path.join(args.out, "identified_parameters.csv"), index=False, encoding="utf-8-sig")
    print("-" * 78, flush=True)
    print("识别到的物理参数（测试集统计）：", flush=True)
    print(par.to_string(index=False), flush=True)

    # ---------------- 业务预报：起报日后 7 天 × 七级降水情景 ----------------
    print("=" * 78, flush=True)
    last_date = df.index[-1]
    fdates = pd.date_range(last_date + pd.Timedelta(days=1), periods=args.horizon, freq="D")
    q_last = float(df.q.iloc[-1])
    win = ds["feat_all"][-args.window:]
    doy_f = fdates.dayofyear.to_numpy(float)
    p_last_obs = float(df.pmean.iloc[-1])

    scen_vals, scen_names, scen_params = [], [], []
    for _i, (num, name, lo, hi, mid0) in enumerate(PRECIP_TIERS):
        mid = float(TIER_MIDS[_i])
        qo, k1o, co, do, ro = rollout_window(nets, ds, win, q_last, doy_f,
                                             np.full(args.horizon, mid), p_last_obs)
        scen_vals.append(np.round(qo[0].astype(float), 2))
        scen_names.append("%s %s (P=%.2fmm)" % (num, name, mid))
        scen_params.append({"等级": "%s %s" % (num, name), "采用降水(mm)": mid,
                            "K1_第1天": round(float(k1o[0, 0]), 4),
                            "C_第1天": float("%.5e" % co[0, 0]),
                            "径流系数Rc": round(float(ro[0, 0]), 3)})
    scen = pd.DataFrame(np.array(scen_vals, dtype=float), index=scen_names,
                        columns=[d.strftime("%m-%d") for d in fdates]).round(2)
    scen.index.name = "降水情景"
    scen.to_csv(os.path.join(args.out, "forecast_scenarios_7tier.csv"), encoding="utf-8-sig")

    doy_now = int(last_date.dayofyear)
    dd = np.abs(doy.astype(int) - doy_now)
    dd = np.minimum(dd, 365 - dd)
    wsel = dd <= 30
    ti = tier_index(df.pmean.to_numpy()[wsel])
    freq = np.bincount(ti, minlength=7) / max(ti.size, 1)
    p_clim = float(np.sum(freq * TIER_MIDS))
    qo_e, k1_e, c_e, _, rc_e = rollout_window(nets, ds, win, q_last, doy_f,
                                              np.full(args.horizon, p_clim), p_last_obs)

    print("起报日：%s，Qout = %.2f m³/s；预报 %s ~ %s"
          % (last_date.date(), q_last, fdates[0].date(), fdates[-1].date()), flush=True)
    print("-" * 78, flush=True)
    print("七级降水情景下的 7 天逐日自回归预报（m³/s）：", flush=True)
    print(scen.to_string(), flush=True)
    print("-" * 78, flush=True)
    print("气候期望情景 P=%.2f mm：%s" % (p_clim, "  ".join("%.2f" % v for v in qo_e[0])), flush=True)
    print("情景包络下界：%s" % "  ".join("%.2f" % v for v in scen.min(axis=0).values), flush=True)
    print("情景包络上界：%s" % "  ".join("%.2f" % v for v in scen.max(axis=0).values), flush=True)

    fc_tbl = scen.T.copy()
    fc_tbl.index.name = "预报日期"
    fc_tbl["气候期望情景"] = np.round(qo_e[0], 2)
    fc_tbl["七情景下界"] = np.round(scen.min(axis=0).values, 2)
    fc_tbl["七情景上界"] = np.round(scen.max(axis=0).values, 2)
    fc_tbl.to_csv(os.path.join(args.out, "forecast_table.csv"), encoding="utf-8-sig")
    print("-" * 78, flush=True)
    print(fc_tbl.to_string(), flush=True)

    tier_df = pd.DataFrame([{"编号": t[0], "等级": t[1], "下限(mm)": t[2], "上限(mm)": t[3],
                             "中值(mm)": t[4], "本次采用值(mm)": round(float(TIER_MIDS[i]), 3),
                             "同期出现频率": round(float(freq[i]), 4)}
                            for i, t in enumerate(PRECIP_TIERS)])
    tier_df.to_csv(os.path.join(args.out, "precip_tiers.csv"), index=False, encoding="utf-8-sig")
    print("-" * 78, flush=True)
    print("国标七级分档（取中值）与预报期同期（±30 天）历史频率：", flush=True)
    print(tier_df.to_string(index=False), flush=True)
    print("气候期望降水 = Σ(频率×中值) = %.3f mm/d" % p_clim, flush=True)

    scen_param_df = pd.DataFrame(scen_params)
    scen_param_df["同期出现频率"] = [round(float(freq[i]), 4) for i in range(len(PRECIP_TIERS))]
    scen_param_df["7天累计降水(mm)"] = [round(float(m) * args.horizon, 1)
                                       for m in scen_param_df["采用降水(mm)"]]
    peak = scen.max(axis=1).to_numpy()
    hist_max = float(df.q.max())
    scen_param_df["7天最大流量(m³/s)"] = np.round(peak, 1)
    scen_param_df["是否超出历史量级"] = ["是（历史最大 %.0f）" % hist_max if p > hist_max else "否"
                                        for p in peak]
    scen_param_df.to_csv(os.path.join(args.out, "scenario_meta.csv"), index=False,
                         encoding="utf-8-sig")

    # ---------------- 最近 7 天回测 ----------------
    hb = int(np.where(dates <= last_date - pd.Timedelta(days=args.horizon))[0][-1])
    hb_true = ds["y_np"][hb]
    hb_p = ds["pfut_raw_np"][hb]
    hb_tier = TIER_MIDS[tier_index(hb_p)]
    hb_pred, *_ = rollout_idx(nets, ds, [hb], p_raw_np=hb_tier[None, :])
    hb_dates = pd.date_range(dates[hb] + pd.Timedelta(days=1), periods=args.horizon, freq="D")
    hb_df = pd.DataFrame({"date": hb_dates.strftime("%Y-%m-%d"),
                          "实测Qout": np.round(hb_true, 2),
                          "预报（分档中值降水）": np.round(hb_pred[0], 2),
                          "实际降水mm": np.round(hb_p, 2),
                          "所用分档中值mm": np.round(hb_tier, 2)})
    hb_df.to_csv(os.path.join(args.out, "last_week_backtest.csv"), index=False, encoding="utf-8-sig")
    print("-" * 78, flush=True)
    print("最近 7 天回测（起报 %s，Q0=%.2f）：" % (dates[hb].date(), ds["q0_np"][hb]), flush=True)
    print(hb_df.to_string(index=False), flush=True)

    # ---------------- 图 ----------------
    plot_losses(log_df[log_df.model == 1] if "model" in log_df.columns else log_df,
                os.path.join(figdir, "01_training_loss.png"))
    plot_metrics(met, os.path.join(figdir, "02_metrics_by_lead.png"), "测试集逐预见期精度对比")
    plot_series(d_te, y_te[:, 0], pred_q[:, 0], os.path.join(figdir, "03_test_series.png"),
                "测试期日径流：实测 vs 1 天预见期预报（未来降水按国标分档取中值）")
    plot_scatter(y_te[:, 0], pred_q[:, 0], os.path.join(figdir, "04_scatter_lead1.png"),
                 "1 天预见期散点（测试集，分档中值降水）")
    plot_scenarios(scen, fdates, q_last, os.path.join(figdir, "05_forecast_scenarios.png"))
    plot_params(d_te, pred_k1[:, 0], pred_rc[:, 0], os.path.join(figdir, "06_identified_params.png"))

    # ---------------- 汇总 Excel ----------------
    info = pd.DataFrame({"项目": [
        "数据文件", "数据区间", "样本总数(天)", "历史样本长度", "预见期", "训练/验证/测试样本",
        "流域面积 S", "物理形式", "物理公式", "纯单位换算系数 1/86.4", "率定 K1（纯物理）",
        "率定 C（纯物理）", "率定 Rc（纯物理）", "模型最优验证损失", "训练轮次", "随机种子",
    ], "取值": [
        os.path.basename(args.data), "%s ~ %s" % (df.index[0].date(), df.index[-1].date()),
        len(df), args.window, args.horizon, "%d / %d / %d" % (len(tr), len(va), len(te)),
        "%.0f km²" % args.area,
        "c=系数形式" if args.physics == "c" else "lr=线性水库标准形式",
        ("Qout(t) = K1*Qout(t-1) + C*(P1+P2+P3+P4)/4*S" if args.physics == "c"
         else "Qout(t) = K1*Qout(t-1) + (1-K1)*Rc*(P1+P2+P3+P4)/4*S/86.4"),
        "%.6f" % (1 / 86.4), "%.4f" % k1c, "%.6f" % cc, "%.4f" % rc,
        "%.6f" % best_val, len(log_df), "%s（%d 个模型集成）" % (seeds, len(nets)),
    ]})

    xlsx = os.path.join(args.out, "LSTM_PINN_结果.xlsx")
    try:
        with pd.ExcelWriter(xlsx, engine="openpyxl") as w:
            info.to_excel(w, sheet_name="1_模型配置", index=False)
            tier_df.to_excel(w, sheet_name="2_降水七级分档", index=False)
            fc_tbl.to_excel(w, sheet_name="3_七天预报")
            scen.to_excel(w, sheet_name="3b_七情景明细")
            scen_param_df.to_excel(w, sheet_name="3c_情景物理参数", index=False)
            hb_df.to_excel(w, sheet_name="4_最近一周回测", index=False)
            met.to_excel(w, sheet_name="5_逐预见期指标", index=False)
            met_all.to_excel(w, sheet_name="6_整体指标", index=False)
            par.to_excel(w, sheet_name="7_识别参数", index=False)
            ser.to_excel(w, sheet_name="8_测试期序列", index=False)
            log_df.to_excel(w, sheet_name="9_训练记录", index=False)
        print("已写出 %s" % xlsx, flush=True)
    except Exception as e:
        print("Excel 汇总失败：%s" % e, flush=True)

    cfg = {}
    for k, v in vars(args).items():
        cfg[k] = float(v) if isinstance(v, (np.integer, np.floating)) else v
    cfg.update({"k1_calibrated": k1c, "c_calibrated": cc, "rc_calibrated": rc,
                "best_val_loss": best_val, "val_nse": float(mv["NSE"]),
                "val_rmse": float(mv["RMSE"]), "val_kge": float(mv["KGE"]), "n_train": int(len(tr)), "n_val": int(len(va)),
                "n_test": int(len(te)), "q_last": q_last, "p_clim": p_clim,
                "forecast_dates": [d.strftime("%Y-%m-%d") for d in fdates]})
    with open(os.path.join(args.out, "run_config.json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

    print("=" * 78, flush=True)
    print("完成。输出目录：%s" % os.path.abspath(args.out), flush=True)


if __name__ == "__main__":
    main()
