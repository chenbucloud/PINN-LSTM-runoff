# -*- coding: utf-8 -*-
from diag_fixed import diag
P = [("榔梨A0@100","B7-A0e100.py","best_model_b7_a0e100_s1.pth"),
     ("榔梨A1@100","B7-A1e100.py","best_model_b7_a1e100_s1.pth"),
     ("榔梨A1@100(重复)","B7-A1e100.py","best_model_b7_a1e100_s1.pth"),
     ("榔梨A2@100","B7-A2e100.py","best_model_b7_a2e100_s1.pth"),
     ("榔梨A3@100","B7-A3e100.py","best_model_b7_a3e100_s1.pth"),
     ("榔梨A4@100","B7-A4e100.py","best_model_b7_a4e100_s1.pth"),
     ("涟水A0","B13-A0e100.py","best_model_a0e100_s1.pth"),
     ("涟水A1","B13-W1.py","best_model_b13_a1w1_s1.pth"),
     ("涟水A2","B13-W2.py","best_model_b13_w2_s1.pth"),
     ("涟水A3","B13-W4.py","best_model_b13_w4_s1.pth"),
     ("涟水A4","B13-W5.py","best_model_b13_w5_s1.pth")]
import os
for tag, sc, ck in P:
    if not os.path.exists(ck): print("%-18s 缺权重 %s" % (tag, ck)); continue
    try: diag(tag, sc, ck)
    except Exception as e: print("%-18s 失败 %s" % (tag, str(e)[:80]))