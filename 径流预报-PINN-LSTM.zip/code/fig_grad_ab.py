# -*- coding: utf-8 -*-
"""(a) cos 双柱 + (b) η 双柱, 共用图例, 17.5 x 9.2 cm"""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"],
    "mathtext.fontset": "stix", "font.size": 8.0, "axes.linewidth": 0.8,
    "xtick.direction": "in", "ytick.direction": "in",
    "xtick.major.width": 0.8, "ytick.major.width": 0.8, "legend.frameon": False})
CM = 1/2.54
B1, B2 = "#0072B2", "#D55E00"
NAMES = ["A0", "A1", "A2", "A3", "A4"]
COS = {"c1": ([0.144,0.206,0.115,0.831,0.723], [0.037,0.098,0.191,0.090,0.173]),
       "c2": ([0.540,0.171,0.630,0.616,0.625], [0.301,0.844,0.315,0.021,0.044])}
ETA = {"c1": ([0.967,0.892,0.869,0.442,0.516], [0.023,0.066,0.161,0.274,0.321]),
       "c2": ([0.992,0.973,0.976,0.732,0.755], [0.004,0.007,0.011,0.030,0.072])}

fig = plt.figure(figsize=(17.5*CM, 9.2*CM))
AX = [(0.072, 0.255, 0.405, 0.600), (0.572, 0.255, 0.405, 0.600)]
SPEC = [("(a)", COS, r"cos($G_{\mathrm{data}}$, $G_{\mathrm{phys}}$)", (-0.80, 1.12), 0.030),
        ("(b)", ETA, r"$\eta$", (0.0, 1.16), 0.030)]
for (lab, D, ylab, ylim, dytxt), ax_pos in zip(SPEC, AX):
    ax = fig.add_axes(ax_pos)
    x = np.arange(len(NAMES)); w = 0.34
    ax.bar(x - w/2, D["c1"][0], width=w, color=B1, edgecolor="black", linewidth=0.5, alpha=0.95,
           label="Catchment 1", zorder=2)
    ax.bar(x + w/2, D["c2"][0], width=w, color=B2, edgecolor="black", linewidth=0.5, alpha=0.95,
           label="Catchment 2", zorder=2)
    ax.errorbar(x - w/2, D["c1"][0], yerr=D["c1"][1], fmt="none", ecolor="black",
                elinewidth=0.8, capsize=2.2, capthick=0.8, zorder=3)
    ax.errorbar(x + w/2, D["c2"][0], yerr=D["c2"][1], fmt="none", ecolor="black",
                elinewidth=0.8, capsize=2.2, capthick=0.8, zorder=3)
    for xi, (m, s) in zip(x - w/2, zip(*D["c1"])):
        ax.text(xi, m + s + dytxt, "%.2f" % m, ha="center", va="bottom", fontsize=5.2)
    for xi, (m, s) in zip(x + w/2, zip(*D["c2"])):
        ax.text(xi, m + s + dytxt, "%.2f" % m, ha="center", va="bottom", fontsize=5.2)
    if lab == "(a)": ax.axhline(0.0, color="black", lw=0.8, zorder=1)
    ax.set_xticks(x); ax.set_xticklabels(NAMES, fontsize=7.4)
    ax.set_xlim(-0.6, len(NAMES)-0.4); ax.set_ylim(*ylim)
    ax.yaxis.set_major_locator(MaxNLocator(5))
    ax.set_ylabel(ylab, labelpad=5); ax.set_xlabel("Configuration", labelpad=3)
    ax.tick_params(labelsize=7.0, length=2.6, pad=2)
    ax.grid(axis="y", ls=":", lw=0.4, color="0.65", alpha=0.7)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    p = ax.get_position()
    fig.text((p.x0+p.x1)/2, 0.120, lab, fontsize=8.6, ha="center", va="center")
h, l = ax.get_legend_handles_labels()
fig.legend(h, l, loc="center", bbox_to_anchor=(0.5, 0.938), ncol=2, fontsize=7.4,
           handlelength=2.2, columnspacing=3.0, labelspacing=0.4)
fig.text(0.5, 0.030, r"$\eta=\|G_{\mathrm{phys}}\|^2/(\|G_{\mathrm{data}}\|^2+\|G_{\mathrm{phys}}\|^2)$."
                     "  Whiskers: $\\pm$1 s.d. over five training seeds; the diagnostic itself is deterministic.",
         fontsize=6.4, ha="center", va="bottom", color="0.25")
fig.savefig("figE_grad_ab.png", dpi=300, facecolor="white")
fig.savefig("figE_grad_ab.svg", facecolor="white")
print("figE_grad_ab.png/.svg ✓")