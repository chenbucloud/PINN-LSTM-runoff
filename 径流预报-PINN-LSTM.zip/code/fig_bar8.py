# -*- coding: utf-8 -*-
"""两流域各 8 个配置: 柱状 + ±sd, (a)(b) 横向并排"""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"],
    "mathtext.fontset": "stix", "font.size": 8.0, "axes.linewidth": 0.8,
    "xtick.direction": "in", "ytick.direction": "in",
    "xtick.major.width": 0.8, "ytick.major.width": 0.8, "legend.frameon": False})
CM = 1/2.54
BLU, GRN, VER, GRY = "#0072B2", "#009E73", "#D55E00", "0.35"
NAMES = ["A0", "A1", "A2", "A3", "A4", "B0", "B1", "H"]
C1 = [(0.9174,0.0119),(0.9277,0.0064),(0.9100,0.0153),(0.8909,0.0575),
      (0.9063,0.0339),(0.9124,0.0077),(0.9063,0.0177),(0.8446,0.0228)]
C2 = [(0.7848,0.1046),(0.6467,0.0214),(0.6512,0.0178),(0.6078,0.0073),
      (0.6121,0.0187),(0.7527,0.1170),(0.6515,0.0225),(0.8075,0.0278)]

H_CM = 7.2
fig = plt.figure(figsize=(17.5*CM, H_CM*CM))
AX = [(0.082, 0.245, 0.400, 0.700), (0.566, 0.245, 0.400, 0.700)]
for ax_pos, DATA, ylim, lab in ((AX[0], C1, (0.80, 0.96), "(a)"),
                                (AX[1], C2, (0.54, 0.90), "(b)")):
    ax = fig.add_axes(ax_pos)
    x = np.arange(len(DATA))
    for xi, (mu, sd) in zip(x, DATA):
        col = GRY if xi == 0 else (BLU if xi <= 4 else (GRN if xi <= 6 else VER))
        hatch = "///" if xi in (0, 5, 7) else None
        ax.bar(xi, mu, width=0.62, color=col, edgecolor="black", linewidth=0.5,
               alpha=0.95, hatch=hatch, zorder=2)
        ax.errorbar(xi, mu, yerr=sd, fmt="none", ecolor="black", elinewidth=0.8,
                    capsize=2.4, capthick=0.8, zorder=3)
        ax.text(xi, mu + sd + (ylim[1]-ylim[0])*0.02, "%.3f" % mu, ha="center",
                va="bottom", fontsize=5.2, zorder=4)
    ax.axhline(DATA[0][0], color=GRY, lw=0.8, ls="--", zorder=1)
    ax.set_xticks(x); ax.set_xticklabels(NAMES, fontsize=7.0)
    ax.set_xlim(-0.65, len(DATA)-0.35); ax.set_ylim(*ylim)
    ax.yaxis.set_major_locator(MaxNLocator(5))
    ax.set_ylabel("NSE", labelpad=4)
    ax.tick_params(labelsize=7.0, length=2.6, pad=2)
    ax.grid(axis="y", ls=":", lw=0.4, color="0.65", alpha=0.7)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    p = ax.get_position()
    fig.text((p.x0+p.x1)/2, 0.095, lab, fontsize=8.6, ha="center", va="center")
fig.text(0.5, 0.020, "Hatched bars: unconstrained references (A0, B0) and the forward form (H).  "
                     "Whiskers: $\\pm$1 s.d. over five seeds; dashed line: A0.",
         fontsize=6.4, ha="center", va="bottom", color="0.25")
fig.savefig("figAB_bars8.png", dpi=300, facecolor="white")
fig.savefig("figAB_bars8.svg", facecolor="white")
print("figAB_bars8.png/.svg ✓ 横向版")