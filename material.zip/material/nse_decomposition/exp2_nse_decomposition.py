
import csv
import importlib.util
import os
import sys

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_PY = os.path.join(HERE, "PINN-LSTM.py")
DEFAULT_CKPT = "best_model_pinn_lstm_peakpinn.pth"
CSV_OUT = os.path.join(HERE, "nse_decomposition.csv")

# 流量段定义
CLASSES = [("Omega1", "Q<100", 0.0, 100.0),
           ("Omega2", "100<=Q<500", 100.0, 500.0),
           ("Omega3", "500<=Q<1500", 500.0, 1500.0),
           ("Omega4", "Q>=1500", 1500.0, np.inf)]


def load_module():
    spec = importlib.util.spec_from_file_location("pinn_lstm", MODEL_PY)
    m = importlib.util.module_from_spec(spec)
    sys.modules["pinn_lstm"] = m
    spec.loader.exec_module(m)
    return m


def build_and_load(m, ckpt, dev):
    cfg = m.Config()
    cfg.print_samples = 0
    data = m.load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
    ds = m.HydroDataset(data, cfg)
    cfg.feat_dim = ds.feat_dim
    model = m.PhysicsLSTM(cfg).to(dev)
    state = torch.load(ckpt, map_location=dev)
    if isinstance(state, dict) and "model_state_dict" in state:
        state = state["model_state_dict"]
    model.load_state_dict(state)
    model.eval()
    return model, ds


def main():
    ckpt = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_CKPT
    m = load_module()
    dev = m.get_device(m.Config())
    print("=" * 108)
    print(f"实验2:NSE 流量段分解   模型: {ckpt}")
    print("=" * 108)
    model, ds = build_and_load(m, ckpt, dev)

    ev = m.evaluate(model, ds, dev)
    Y = np.asarray(ev["true"], dtype=np.float64).ravel()     # 实测(物理量纲)
    P = np.asarray(ev["pred"], dtype=np.float64).ravel()     # 预测
    n = Y.size
    qbar = Y.mean()
    sse_obs = float(np.sum((Y - qbar) ** 2))                 # NSE 分母
    sse_mod = float(np.sum((Y - P) ** 2))                    # NSE 分子
    nse = 1.0 - sse_mod / (sse_obs + 1e-12)
    print(f"样本天数 {n}  |  实测均值 {qbar:.1f} m³/s  |  最大值 {Y.max():.0f} m³/s")
    print(f"NSE = 1 - {sse_mod:.3e} / {sse_obs:.3e} = {nse:.4f}")
    print()

    rows = []
    print(f"{'段':<8}{'区间':<14}{'天数':>7}{'天占比':>9}{'方差占比':>10}"
          f"{'误差占比':>10}{'段内NSE':>10}{'均实测':>9}{'均预测':>9}{'偏差比':>8}")
    print("-" * 108)
    for name, lab, lo, hi in CLASSES:
        sel = (Y >= lo) & (Y < hi)
        k = int(sel.sum())
        if k == 0:
            continue
        sse_o = float(np.sum((Y[sel] - qbar) ** 2))
        sse_m = float(np.sum((Y[sel] - P[sel]) ** 2))
        nse_c = 1.0 - sse_m / (sse_o + 1e-12)
        rows.append(dict(cls=name, range=lab, days=k, days_pct=100 * k / n,
                         var_pct=100 * sse_o / sse_obs, err_pct=100 * sse_m / sse_mod,
                         nse=nse_c, mean_obs=Y[sel].mean(), mean_pred=P[sel].mean(),
                         ratio=P[sel].mean() / (Y[sel].mean() + 1e-9)))
        r = rows[-1]
        print(f"{name:<8}{lab:<14}{k:>7}{r['days_pct']:>8.2f}%{r['var_pct']:>9.2f}%"
              f"{r['err_pct']:>9.2f}%{nse_c:>10.3f}{r['mean_obs']:>9.1f}"
              f"{r['mean_pred']:>9.1f}{r['ratio']:>8.3f}")
    print("-" * 108)
    print(f"{'合计':<22}{n:>7}{100.0:>8.2f}%{100.0:>9.2f}%{100.0:>9.2f}%"
          f"{nse:>10.3f}{Y.mean():>9.1f}{P.mean():>9.1f}")

    # ---------------------------------------------------------- 关键结论
    top = rows[-1] if rows else None
    if top:
        print()
        print(f"  仅占测试期 {top['days_pct']:.1f}% 的高流量日(Q>1500 m³/s)")
        print(f"    贡献了 NSE 分母(观测方差)的 {top['var_pct']:.1f}%")
        print(f"    和 NSE 分子(模型平方误差)的 {top['err_pct']:.1f}%")
        hi3 = [r for r in rows if r["cls"] in ("Omega3", "Omega4")]
        print(f"  高流量段(>500 m³/s)合计:天数 {sum(r['days_pct'] for r in hi3):.1f}%"
              f" / 方差 {sum(r['var_pct'] for r in hi3):.1f}%"
              f" / 误差 {sum(r['err_pct'] for r in hi3):.1f}%")

    with open(CSV_OUT, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for r in rows:
            w.writerow({k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items()})
    print(f"\n结果已保存: {CSV_OUT}")


if __name__ == "__main__":
    main()
