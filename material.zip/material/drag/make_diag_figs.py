
import io, os, csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.size": 8, "font.family": "DejaVu Sans", "axes.linewidth": 0.8,
                     "axes.grid": True, "grid.alpha": 0.30, "grid.linewidth": 0.5,
                     "xtick.major.width": 0.8, "ytick.major.width": 0.8, "legend.frameon": False})
CW = 3.543          # 9 cm
DPI = 300
C_A, C_B, C_C = "#4d4d4d", "#1f77b4", "#d62728"

def load(f):
    rs = list(csv.DictReader(io.open(f, encoding="utf-8-sig")))
    return (np.array([float(r["NSE"]) for r in rs]), np.array([float(r["PBIAS_pct"]) for r in rs]),
            np.array([float(r["RMSE"]) for r in rs]), np.array([float(r["MAE"]) for r in rs]))

nA, pA, rA, mA = load("results_perlead_A0.csv")
nB, pB, rB, mB = load("results_perlead_pinn_lam1.csv")
nC, pC, rC, mC = load("results_perlead_pinn_lam1_nosm.csv")
x = np.arange(1, 8)
lab = ["D%d" % i for i in range(1, 8)]

# ---------- Fig 1: 逐预见期 ----------
fig, ax = plt.subplots(2, 1, figsize=(CW, 6.6), dpi=DPI, sharex=True)
SER = [(nA, pA, C_A, "o", "A  unconstrained (\u03bb = 0)"),
       (nB, pB, C_B, "s", "B  PINN (\u03bb = 1, \u03c9 = 2)"),
       (nC, pC, C_C, "^", "C  PINN (\u03bb = 1, \u03c9 = 0)")]
for n_, p_, c, m, nm in SER:
    ax[0].plot(x, n_, m + "-", color=c, ms=3.5, lw=1.2, label=nm)
    ax[1].plot(x, p_, m + "-", color=c, ms=3.5, lw=1.2, label=nm)
ax[0].set_ylabel("NSE"); ax[0].set_ylim(0.72, 0.85)
ax[0].legend(loc="lower left", fontsize=6.0, frameon=True, framealpha=0.92,
             borderpad=0.25, handlelength=1.6, labelspacing=0.25)
ax[0].text(0.02, 0.96, "(a)", transform=ax[0].transAxes, fontsize=7, va="top")
ax[1].axhline(0, color="k", lw=0.7, ls=":")
ax[1].set_ylabel("PBIAS (%)"); ax[1].set_xlabel("Lead time")
ax[1].set_xticks(x); ax[1].set_xticklabels(lab)
ax[1].legend(loc="lower left", fontsize=6.0, frameon=True, framealpha=0.92,
             borderpad=0.25, handlelength=1.6, labelspacing=0.25)
ax[1].text(0.02, 0.96, "(b)", transform=ax[1].transAxes, fontsize=7, va="top")
ax[1].annotate("over-estimation\ngrows with lead time", xy=(7, pA[-1]), xytext=(4.3, 15),
               fontsize=6, arrowprops=dict(arrowstyle="->", lw=0.7, color=C_A), color=C_A)
ax[1].annotate("almost unbiased", xy=(7, pC[-1]), xytext=(3.4, -13),
               fontsize=6, arrowprops=dict(arrowstyle="->", lw=0.7, color=C_C), color=C_C)
fig.tight_layout(); fig.savefig("fig_perlead_ABC.png", dpi=DPI); plt.close(fig)
print("fig_perlead_ABC.png  OK  (9.0 cm 宽)")

# ---------- Fig 2: 物理损失两项分解 ----------
d = list(csv.DictReader(io.open("diag_grad_trained.csv", encoding="utf-8")))
mres, muh = np.mean([float(r["L_res"]) for r in d]), np.mean([float(r["L_uh"]) for r in d])
mgr, mgu = np.mean([float(r["norm_res"]) for r in d]), np.mean([float(r["norm_uh"]) for r in d])
mgd = np.mean([float(r["norm_data"]) for r in d])
fig, ax = plt.subplots(1, 2, figsize=(CW, 2.9), dpi=DPI)
ax[0].bar([0, 1], [mres, muh], color=[C_B, "#ff7f0e"], width=0.55, edgecolor="k", lw=0.6)
ax[0].set_xticks([0, 1]); ax[0].set_xticklabels(["gated\nresidual", "UH curvature\npenalty"], fontsize=6.5)
ax[0].set_ylabel("mean $L_{phys}$ term", fontsize=7.5)
for i, v in enumerate([mres, muh]):
    ax[0].text(i, v, "  %.3f\n  (%.1f %%)" % (v, 100 * v / (mres + muh)), ha="center", va="bottom", fontsize=6)
ax[1].bar([0, 1], [mgr, mgu], color=[C_B, "#ff7f0e"], width=0.55, edgecolor="k", lw=0.6)
ax[1].set_xticks([0, 1]); ax[1].set_xticklabels(["gated\nresidual", "UH curvature\npenalty"], fontsize=6.5)
ax[1].set_ylabel("mean gradient norm", fontsize=7.5)
for i, v in enumerate([mgr, mgu]):
    ax[1].text(i, v, "  %.4f\n  (%.1f %%)" % (v, 100 * v / (mgr + mgu)), ha="center", va="bottom", fontsize=6)
ax[0].set_ylim(0, mres * 1.45); ax[1].set_ylim(0, mgr * 1.45)
fig.tight_layout(); fig.savefig("fig_phys_split.png", dpi=DPI); plt.close(fig)
print("fig_phys_split.png  OK  |  L_res=%.4f L_uh=%.4f (%.2f %%) | ||G_res||=%.4f ||G_uh||=%.4f (%.2f %%) | ||G_data||=%.4f"
      % (mres, muh, 100 * muh / (mres + muh), mgr, mgu, 100 * mgu / (mgr + mgu), mgd))

# ---------- Fig 3: 梯度可达性(需 init csv) ----------
if os.path.exists("diag_grad_init.csv"):
    di = list(csv.DictReader(io.open("diag_grad_init.csv", encoding="utf-8")))
    def mm(rows, k): return float(np.mean([float(r[k]) for r in rows]))
    fig, ax = plt.subplots(1, 2, figsize=(CW, 3.0), dpi=DPI)
    lam = np.array([0.01, 0.05, 0.1, 0.3, 1.0, 3.0])
    for rows, c, m, nm in [(di, "#2ca02c", "o", "at initialisation"), (d, C_C, "^", "after training")]:
        nd, nr = mm(rows, "norm_data"), mm(rows, "norm_res")
        ax[0].semilogx(lam, 100 * lam * nr / (nd + lam * nr), m + "-", color=c, ms=3, lw=1.2, label=nm)
    ax[0].axhline(1, color="k", lw=0.6, ls=":"); ax[0].set_xlabel("λ (physics weight)", fontsize=7.5)
    ax[0].set_ylabel("gradient share η (%)", fontsize=7.5); ax[0].legend(fontsize=6.3, loc="upper left")
    ci, ct = mm(di, "cos_dr"), mm(d, "cos_dr")
    ax[1].bar([0, 1], [ci, ct], yerr=[float(np.std([float(r["cos_dr"]) for r in di])), float(np.std([float(r["cos_dr"]) for r in d]))],
              color=["#2ca02c", C_C], width=0.5, capsize=3, edgecolor="k", lw=0.6)
    ax[1].axhline(0, color="k", lw=0.7)
    ax[1].set_xticks([0, 1]); ax[1].set_xticklabels(["initialised", "trained"], fontsize=7)
    ax[1].set_ylabel("cos φ  ⟨$G_{data}$,$G_{res}$⟩", fontsize=7.5); ax[1].set_ylim(-1, 1.15)
    for i, v in enumerate([ci, ct]): ax[1].text(i, v + (0.09 if v > 0 else -0.16), "%+.3f" % v, ha="center", fontsize=6.5)
    fig.tight_layout(); fig.savefig("fig_diag_grad.png", dpi=DPI); plt.close(fig)
    print("fig_diag_grad.png  OK  |  cos init=%+.4f  cos trained=%+.4f" % (ci, ct))
else:
    print("fig_diag_grad.png  跳过(等 diag_grad_init.csv)")