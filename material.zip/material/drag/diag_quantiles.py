
import os, sys, importlib.util, csv, argparse
os.environ["HYDRO_NO_SHOW"] = "1"
import numpy as np, torch
ap = argparse.ArgumentParser()
ap.add_argument("ckpt", nargs="?", default="model_lstm_lam0.pth")
ap.add_argument("--csv", action="store_true"); ap.add_argument("--fig", default="fig_quantile_compression.png")
a = ap.parse_args()

spec = importlib.util.spec_from_file_location("p0", "PINN-LSTM-lstm.py")
M = importlib.util.module_from_spec(spec); sys.modules["p0"] = M; spec.loader.exec_module(M)
pkg = torch.load(a.ckpt, map_location="cpu", weights_only=False)
cfg = M.Config()
for k, v in pkg["config"].items():
    if hasattr(cfg, k): setattr(cfg, k, v)
dev = M.get_device(cfg)
data = M.load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
ds = M.HydroDataset(data, cfg); cfg.feat_dim = ds.feat_dim
mo = M.PhysicsLSTM(cfg).to(dev); mo.load_state_dict(pkg["model_state_dict"]); mo.eval()
ev = M.evaluate(mo, ds, dev)
Y, P = np.asarray(ev["true"]).ravel(), np.asarray(ev["pred"]).ravel()

QS = [1, 5, 10, 25, 50, 75, 90, 95, 97, 99, 99.5, 99.9]
rows = []
print("=== 分位数对比 (%s, n=%d) ===" % (a.ckpt, Y.size))
print("   %-8s %10s %10s %9s" % ("Pct", "Observed", "Predicted", "ratio"))
for q in QS:
    o, p = np.quantile(Y, q / 100), np.quantile(P, q / 100)
    r = p / (o + 1e-9)
    rows.append((q, o, p, r))
    print("   P%-7s %10.1f %10.1f %9.3f  (%+.1f %%)" % (q, o, p, r, 100 * (r - 1)))
# 交叉点(粗扫)
qs = np.arange(1, 99.95, 0.25)
rr = np.array([np.quantile(P, q / 100) / (np.quantile(Y, q / 100) + 1e-9) for q in qs])
_ge = np.where(rr >= 1.0)[0]
cross = qs[_ge[-1]] if len(_ge) else float("nan")
below = rr[np.logical_and(qs >= 25, qs <= cross)]; above = rr[qs > cross]
print("\n=== 核验 ===")
print("   交叉点(ratio=1) ≈ P%.1f" % cross)
print("   交叉点以下: 比值范围 %.2f ~ %.2f  (高估 %.0f %% ~ %.0f %%)" % (below.min(), below.max(), 100*(below.min()-1), 100*(below.max()-1)))
print("   交叉点以上: 最低比值 %.3f  (低估 %.0f %%)" % (above.min(), 100*(1-above.min())))
print("   最大值: 观测 %.0f / 预测 %.0f  ⇒ 亏缺 %.1f %%" % (Y.max(), P.max(), 100*(P.max()/Y.max()-1)))
if a.csv:
    with open("quantile_compression.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh); w.writerow(["quantile_pct", "observed", "predicted", "ratio"])
        for q, o, p, r in rows: w.writerow([q, "%.2f" % o, "%.2f" % p, "%.3f" % r])
    print("\n已写 quantile_compression.csv")

import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 8, "font.family": "DejaVu Sans", "axes.linewidth": 0.8,
                     "axes.grid": True, "grid.alpha": 0.3, "grid.linewidth": 0.5, "legend.frameon": False})
fig, ax = plt.subplots(1, 2, figsize=(6.89, 2.55), dpi=300)
fig.subplots_adjust(wspace=0.45)

ax[0].plot(qs, rr, color="#d62728", lw=1.4)
ax[0].axhline(1.0, color="k", lw=0.9, ls="--")
ax[0].axvline(cross, color="#1f77b4", lw=0.9, ls=":")
BB = dict(fc="white", ec="none", alpha=0.85, pad=1.5)
ax[0].text(cross - 2.0, 1.42, "crossover P%.0f" % cross, fontsize=6.5, color="#1f77b4",
           ha="right", va="top", bbox=BB)
ax[0].annotate("over-predicted", xy=(50, 1.43), fontsize=6.5, color="#d62728",
               ha="center", va="center", bbox=BB)
ax[0].annotate("under-predicted", xy=(85, 0.78), fontsize=6.5, color="#d62728",
               ha="center", va="center", bbox=BB)
ax[0].set_xlabel("percentile of the distribution (%)", fontsize=7.5)
ax[0].set_ylabel("$Q_{pred} / Q_{obs}$", fontsize=7.5)
ax[0].set_ylim(0.60, 1.48); ax[0].set_xlim(0, 100)

qg = np.arange(1, 99.9, 0.5)
OY = np.array([np.quantile(Y, q / 100) for q in qg])
OP = np.array([np.quantile(P, q / 100) for q in qg])
ax[1].plot([0, 3700], [0, 3700], "k--", lw=0.9)
ax[1].plot(OY, OP, color="#1f77b4", lw=1.5)
ax[1].annotate("compressed\ntoward the centre", xy=(2700, 1150), fontsize=6.5, color="#1f77b4",
               ha="center", va="center", bbox=BB)
ax[1].set_xlabel("observed quantile (m$^3$ s$^{-1}$)", fontsize=7.5)
ax[1].set_ylabel("predicted quantile (m$^3$ s$^{-1}$)", fontsize=7.5)
ax[1].set_xlim(0, 3800); ax[1].set_ylim(0, 3800)

fig.tight_layout(pad=0.4)
fig.savefig(a.fig, dpi=300, bbox_inches="tight", pad_inches=0.03)
plt.close(fig)
print("图 -> %s" % a.fig)
