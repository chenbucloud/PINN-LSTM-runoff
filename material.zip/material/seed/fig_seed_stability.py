
import io, re, csv, os
import numpy as np

CSV = "seed_stability.csv"
# (名称, 日志, 颜色, 标记, 论文单次值或 None)
GROUPS = [("C   (lambda=1, omega_uh=0)", "seed_runs.log",       "#d62728", "o", 0.8141),
          ("A0  (lambda=0, omega_uh=2)", "base_seed_runs.log",  "#7f7f7f", "s", 0.7855),
          ("A0w (lambda=0, omega_uh=0)", "base0_seed_runs.log", "#2ca02c", "^", None)]

def parse(path):
    if not os.path.exists(path): return []
    s = io.open(path, encoding="utf-8", errors="replace").read()
    parts = re.split(r"#{6,}\s*SEED\s+(\d+)\s*#{6,}", s)
    out = []
    for i in range(1, len(parts) - 1, 2):
        m = re.search(r"最佳测试 NSE\s*=\s*([\d.]+)\s*@\s*Epoch\s*(\d+)", parts[i + 1])
        if m: out.append((int(parts[i]), float(m.group(1)), int(m.group(2))))
    return sorted(out)

data = [(n, parse(f), c, mk, rep) for n, f, c, mk, rep in GROUPS]
data = [d for d in data if d[1]]
print("=== 多种子汇总 ===")
for name, rows, col, mk, rep in data:
    v = np.array([r[1] for r in rows]); e = np.array([r[2] for r in rows])
    print("  %-28s n=%d  NSE均值 %.4f  标准差 %.4f  极差 %.4f  最佳轮 %d-%d  报告单次 %s" % (
        name, len(v), v.mean(), v.std(ddof=1) if len(v) > 1 else 0.0, v.max() - v.min(),
        e.min(), e.max(), ("%.4f" % rep) if rep else "-"))
d1 = {r[0]: r[1] for r in (data[0][1] if data else [])}
for k in range(1, len(data)):
    dk = {r[0]: r[1] for r in data[k][1]}; ks = sorted(set(d1) & set(dk))
    if len(ks) > 1:
        g = np.array([d1[x] - dk[x] for x in ks])
        print("  配对增益 C - %s: %+.4f +/- %.4f (n=%d) | 为正 %d/%d | 逐种子 %s" % (
            data[k][0].split()[0], g.mean(), g.std(ddof=1), len(g), int((g > 0).sum()), len(g),
            " ".join("s%d%+.4f" % (x, d1[x] - dk[x]) for x in ks)))

import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 7.5, "font.family": "DejaVu Sans", "axes.linewidth": 0.8,
                     "axes.grid": True, "grid.alpha": 0.3, "grid.linewidth": 0.5, "legend.frameon": False})
CW = 3.543
fig, ax = plt.subplots(2, 1, figsize=(CW, 3.60), dpi=300, height_ratios=[2.4, 1.0])
for name, rows, col, mk, rep in data:
    x = np.array([r[0] for r in rows]); v = np.array([r[1] for r in rows]); e = np.array([r[2] for r in rows])
    mu = v.mean(); sd = v.std(ddof=1) if len(v) > 1 else 0.0
    ax[0].axhspan(mu - sd, mu + sd, color=col, alpha=0.12, zorder=0)
    ax[0].axhline(mu, color=col, lw=1.3, zorder=1)
    ax[0].plot(x, v, mk + "-", color=col, ms=3.6, lw=1.0,
               label="%s   %.4f +/- %.4f (n=%d)" % (name, mu, sd, len(v)))
    if rep is not None:
        ax[0].plot([6.15], [rep], marker="*", ms=8, mfc="none", mec=col, mew=1.0, ls="none")
        ax[0].annotate("%.4f" % rep, xy=(6.35, rep), fontsize=5.8, color=col, va="center")
    ax[1].plot(x, e, mk + "-", color=col, ms=3.0, lw=0.9)
ax[0].set_ylabel("NSE (test set)"); ax[0].set_xlabel("random seed index")
ax[0].set_xlim(0.4, 7.3)
ax[0].text(0.985, 0.94, "(a)", transform=ax[0].transAxes, fontsize=6.8, ha="right", va="top")
ax[1].set_ylabel("best epoch"); ax[1].set_xlabel("random seed index"); ax[1].set_xlim(0.4, 7.3)
ax[1].text(0.985, 0.86, "(b)", transform=ax[1].transAxes, fontsize=6.8, ha="right", va="top")
h0, l0 = ax[0].get_legend_handles_labels()
if len(data) > 1:
    ax[1].legend(h0 + [plt.Line2D([], [], color="none")], l0 + ["star = value reported in the single run"],
                 loc="upper center", bbox_to_anchor=(0.5, -0.42), ncol=1, fontsize=5.7)
else:
    ax[1].legend(h0, l0, loc="upper center", bbox_to_anchor=(0.5, -0.42), ncol=1, fontsize=5.7)
fig.savefig("fig_seed_stability.png", dpi=300, bbox_inches="tight")
print("图 -> fig_seed_stability.png")
with open(CSV, "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.writer(fh); w.writerow(["config", "seed", "NSE", "best_epoch"])
    for name, rows, *_ in data:
        for sid, v, e in rows: w.writerow([name, sid, "%.4f" % v, e])
print("已写", CSV)