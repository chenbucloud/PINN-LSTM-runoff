
import io, os,  csv, sys, subprocess

CSV = "ablation.csv"
if not os.path.exists(CSV):
    print("ablation.csv 不存在"); sys.exit(1)
rows = {}
with io.open(CSV, encoding="utf-8") as f:
    for d in csv.DictReader(f):
        if d.get("config"): rows[d["config"].strip()] = d
print("ablation.csv 中已完成:", sorted(rows.keys()))
missing = [c for c in ("A1", "A2", "A3", "A4") if c not in rows]
if missing:
    print("尚未完成:", missing, "-> 只填已完成的行,其余保留 [PENDING]")

A0 = {"lambda": "0", "params": "frozen", "calib": "—", "gate": "off", "uh": "2.0",
      "k1": ("—", "—"), "al": ("—", "—"), "ga": ("—", "—"),
      "NSE": "**0.7855**", "NSEp": "**0.7081**", "NSEl": "**0.4735**", "dev": "**-25.7 %**"}
LABEL = {"A0": "—", "A1": "criterion (2), unfixed", "A2": "criterion (2), fixed",
         "A3": "criterion (3), fixed", "A4": "attribution of A3"}
PEND = "[PENDING]"

def cell(v, bold=False):
    s = v.strip() if v else PEND
    return "**%s**" % s if bold else s

def pair(d, a, b):
    if d is None: return (PEND, PEND)
    return (d.get(a, "").strip(), d.get(b, "").strip())

body = []
for c in ("A0", "A1", "A2", "A3", "A4"):
    d = rows.get(c)
    if c == "A0":
        r = A0
        k1, al, ga = r["k1"], r["al"], r["ga"]
        lam, par, cal, gate, uh = r["lambda"], r["params"], r["calib"], r["gate"], r["uh"]
        nse, nsep, nsel, dev = r["NSE"], r["NSEp"], r["NSEl"], r["dev"]
    else:
        lam = "%s" % (d["lambda"] if d else "1.0")
        par = d["params_pt"] if d else "—"
        cal = "flood-weighted" if c in ("A3", "A4") else "ordinary LS"
        gate = d["gate"] if d else "—"
        uh = "**0.0**" if c == "A4" else "2.0"
        k1, al, ga = pair(d, "k1_calib", "k1_train"), pair(d, "alpha_calib", "alpha_train"), pair(d, "gamma_calib", "gamma_train")
        nse  = cell(d["NSE"], True) if d else PEND
        nsep = cell(d["NSE_peak"], True) if d else PEND
        nsel = cell(d["NSE_low"], True) if d else PEND
        dev  = cell(d["peak_dev_pct"] + " %", True) if d else PEND
    body.append("| %s | %s | %s | %s | %s | %s | %s | %s -> %s | %s -> %s | %s -> %s | %s | %s | %s | %s |" % (
        c, LABEL[c], lam, par, cal, gate, uh,
        k1[0], k1[1], al[0], al[1], ga[0], ga[1], nse, nsep, nsel, dev))

HEAD = ("| Config. | Isolates | lambda | Physical parameters | Calibration criterion | Flow gate | omega_uh | "
        "k1 cal -> trained | alpha cal -> trained | gamma cal -> trained | NSE | NSE_peak | NSE_low | Peak dev. |\n"
        "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
NEW = "**Table 8. Ablation design and results.**\n\n" + HEAD + "\n" + "\n".join(body) + "\n"