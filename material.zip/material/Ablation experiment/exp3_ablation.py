
import argparse, importlib.util, io, os, sys, time
import numpy as np, torch, torch.nn.functional as F

spec = importlib.util.spec_from_file_location("pinn", "PINN-LSTM.py")
M = importlib.util.module_from_spec(spec); sys.modules["pinn"] = M; spec.loader.exec_module(M)

NO_CAL = dict(calib_flow_weight_ref=1e9)          # 关闭洪峰加权 = 普通最小二乘
BASE = dict(physics_weight=1.0, freeze_physics=False, phys_q_gate=0.0, phys_gate_floor=1.0,
            uh_smooth_weight=2.0, calibrate_physics=True, print_samples=0, print_samples_file="")
GATED = dict(BASE, freeze_physics=True, calib_flow_weight_ref=500.0,
             phys_q_gate=400.0, phys_gate_floor=0.0)
CFG = [
 ("A0", "baseline: lambda=0 (pure LSTM)",                 dict(BASE, physics_weight=0.0, freeze_physics=True, **NO_CAL)),
 ("A1", "physics on, params trainable, LS calibration, no gate", dict(BASE, **NO_CAL)),
 ("A2", "A1 + parameters calibrated then frozen",          dict(BASE, freeze_physics=True, **NO_CAL)),
 ("A3", "A2 + flood-weighted calibration + flow gate (full recipe)", dict(GATED)),
 ("A4", "A3 with unit-hydrograph smoothness removed",      dict(GATED, uh_smooth_weight=0.0)),
]
ap = argparse.ArgumentParser()
ap.add_argument("--epochs", type=int, default=1500)
ap.add_argument("--only", default=""); ap.add_argument("--skip", default="")
ap.add_argument("--csv", default="ablation.csv")
a = ap.parse_args()

done = set()
if os.path.exists(a.csv):
    for ln in io.open(a.csv, encoding="utf-8").read().splitlines()[1:]:
        if ln.strip(): done.add(ln.split(",")[0])
HDR = ("config,desc,lambda,params_pt,gate,NSE,RMSE,MAE,PBIAS,NSE_low,NSE_peak,"
       "D1,D2,D3,D4,D5,D6,D7,peak_obs,peak_pred,peak_dev_pct,"
       "k1_calib,k1_train,alpha_calib,alpha_train,gamma_calib,gamma_train,minutes")
if not os.path.exists(a.csv):
    io.open(a.csv, "w", encoding="utf-8").write(HDR + "\n")

device = M.get_device(M.Config()); print("device =", device, flush=True)
data = M.load_hydro_data(M.Config().file_path); ds = M.HydroDataset(data, M.Config())

def params(model):
    return (float(model.get_k1().detach().cpu()),
            float(F.softplus(model.alpha_run_log).detach().cpu()),
            float(1 + F.softplus(model.gamma_run_log).detach().cpu()))

for name, desc, ov in CFG:
    if a.only and name != a.only: continue
    if name in a.skip.split(",") or name in done:
        print("跳过 %s" % name, flush=True); continue
    cfg = M.Config()
    for k, v in ov.items(): setattr(cfg, k, v)
    cfg.epochs = a.epochs; cfg.tag = "abl_" + name
    M.set_seed(cfg.seed)
    model = M.PhysicsLSTM(cfg).to(device)
    if cfg.calibrate_physics:
        M.calibrate_physics(model, data, cfg, verbose=False)
    k1c, ac, gc = params(model)
    print("[%s] %s\n     率定: k1=%.4f alpha=%.4f gamma=%.4f" % (name, desc, k1c, ac, gc), flush=True)
    t0 = time.time(); M.train_model(model, dataset=ds, cfg=cfg, device=device); mins = (time.time()-t0)/60
    ck = "best_model_%s.pth" % cfg.tag
    if os.path.exists(ck): model.load_state_dict(torch.load(ck, map_location=device, weights_only=True))
    model.eval()
    k1t, at, gt = params(model)
    ev = M.evaluate(model, ds, device); Y, P = ev["true"], ev["pred"]
    pdev = 100*(ev["peak_pred"]-ev["peak_true"])/ev["peak_true"]
    row = [name, '"%s"' % desc, str(ov.get("physics_weight",1.0)),
           "frozen" if ov.get("freeze_physics") else "trainable",
           "on" if ov.get("phys_gate_floor",1.0)==0.0 else "off",
           "%.4f"%ev["nse"], "%.2f"%ev["rmse"], "%.2f"%float(np.mean(np.abs(Y-P))),
           "%+.2f"%(100*(P.sum()-Y.sum())/Y.sum()), "%.4f"%ev["nse_low"], "%.4f"%ev["nse_peak"]] \
        + ["%.4f"%x for x in ev["nse_days"]] \
        + ["%.0f"%ev["peak_true"], "%.0f"%ev["peak_pred"], "%+.1f"%pdev,
           "%.4f"%k1c, "%.4f"%k1t, "%.4f"%ac, "%.4f"%at, "%.4f"%gc, "%.4f"%gt, "%.1f"%mins]
    io.open(a.csv, "a", encoding="utf-8").write(",".join(row)+"\n")
    print("[%s] NSE %.4f | NSE_peak %.4f | NSE_low %.4f | PBIAS %+.2f%% | 洪峰 %+.1f%% | "
          "漂移 k1 %.3f->%.3f (%.1f min)" % (name, ev["nse"], ev["nse_peak"], ev["nse_low"],
          100*(P.sum()-Y.sum())/Y.sum(), pdev, k1c, k1t, mins), flush=True)
print("\n完成 -> %s" % a.csv, flush=True)