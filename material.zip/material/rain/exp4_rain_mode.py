
import argparse, importlib.util, io, os, sys, time, csv
import numpy as np, torch

spec = importlib.util.spec_from_file_location("pinn", "PINN-LSTM.py")
M = importlib.util.module_from_spec(spec); sys.modules["pinn"] = M; spec.loader.exec_module(M)

# ---- 细档:非均匀分档(低雨量分辨率高);代表值 0.5/3/10/22.5/40/75/125 ----
FINE_EDGES = np.array([1.0, 5.0, 15.0, 30.0, 50.0, 100.0])
FINE_REPS  = np.array([0.5, 3.0, 10.0, 22.5, 40.0, 75.0, 125.0])
MODE = ["coarse"]
def _quant(x):
    y = x.copy(); pos = x > 0
    if pos.any():
        y[pos] = FINE_REPS[np.searchsorted(FINE_EDGES, x[pos], side="left")]
    return y

def _future_bucketed_patched(self, i):
    s, p = self.seq_len, self.pred_step
    fut = self.feat_raw[i:i + p].copy()
    for c in M.IDX_P_ALL:
        x = fut[:, c]
        if MODE[0] == "fine":
            fut[:, c] = _quant(x)
        elif MODE[0] == "coarse":
            w = self.future_rain_bucket; pos = x > 0
            fut[pos, c] = (np.floor(x[pos] / w) + 0.5) * w
    api_up = self.feat_raw[i - 1, M.I_API_UP]; api_loc = self.feat_raw[i - 1, M.I_API_LOC]
    k = 0.9
    for t in range(p):
        api_up = fut[t, M.IDX_P_UP].mean() + k * api_up
        api_loc = fut[t, M.IDX_P_LOC].mean() + k * api_loc
        fut[t, M.I_API_UP] = api_up; fut[t, M.I_API_LOC] = api_loc
    fn = self._norm(fut, self.f_min, self.f_max)
    fn[:, M.I_QOUT] = 0.0
    return fn
M.HydroDataset._future_bucketed = _future_bucketed_patched

ap = argparse.ArgumentParser()
ap.add_argument("--epochs", type=int, default=1500); ap.add_argument("--only", default="")
ap.add_argument("--csv", default="rain_mode.csv"); a = ap.parse_args()

CFG_A4 = dict(physics_weight=1.0, freeze_physics=True, calibrate_physics=True,
              calib_flow_weight_ref=500.0, phys_q_gate=400.0, phys_gate_floor=0.0,
              uh_smooth_weight=0.0, print_samples=0, print_samples_file="")
MODES = [("observed", "observed precipitation (no quantisation)", 0.0),
         ("fine",     "fine non-uniform quantisation",             50.0)]
HDR = "mode,desc,bucket,NSE,RMSE,MAE,PBIAS,NSE_low,NSE_peak,D1,D2,D3,D4,D5,D6,D7,peak_obs,peak_pred,peak_dev_pct,rain_rel,minutes"
if not os.path.exists(a.csv): io.open(a.csv, "w", encoding="utf-8").write(HDR + "\n")
done = set()
if os.path.exists(a.csv):
    for d in csv.DictReader(io.open(a.csv, encoding="utf-8")):
        if d.get("mode"): done.add(d["mode"])

base = M.Config(); dev = M.get_device(base)
data = M.load_hydro_data(base.file_path)
CFG0 = M.Config()
print("device =", dev, flush=True)

# 预报期总雨量(三种设置,用于表 11 的相对体积列)
raw = None
for mode, desc, bucket in MODES + [("coarse", "coarse 50 mm", 50.0)]:
    if raw is None:
        d0 = M.HydroDataset(data, CFG0); raw = d0.feat_raw; sl = d0.seq_len; ps = d0.pred_step
    tot = 0.0
    for i in range(sl, len(raw) - ps):
        fut = raw[i:i + ps, M.IDX_P_ALL]
        if mode == "fine": fut = _quant(fut)
        elif mode == "coarse":
            f2 = fut.copy(); pos = f2 > 0; f2[pos] = (np.floor(f2[pos]/50.0)+0.5)*50.0; fut = f2
        tot += fut.sum()
    print("  预报期总雨量 [%s] = %.0f mm" % (mode, tot), flush=True)
    if mode == "coarse": rel_coarse = tot
    if mode == "observed": rel_obs = tot
    globals()["rel_" + mode] = tot

for mode, desc, bucket in MODES:
    if a.only and mode != a.only: continue
    if mode in done: print("跳过", mode, flush=True); continue
    MODE[0] = mode
    cfg = M.Config()
    for k, v in CFG_A4.items(): setattr(cfg, k, v)
    cfg.future_rain_bucket = bucket
    cfg.epochs = a.epochs; cfg.tag = "rain_" + mode
    M.set_seed(cfg.seed)
    ds = M.HydroDataset(data, cfg)
    model = M.PhysicsLSTM(cfg).to(dev)
    if cfg.calibrate_physics: M.calibrate_physics(model, data, cfg, verbose=False)
    print("\n[%s] %s | bucket=%.1f | 训练中..." % (mode, desc, bucket), flush=True)
    t0 = time.time(); M.train_model(model, dataset=ds, cfg=cfg, device=dev); mins = (time.time()-t0)/60
    ck = "best_model_%s.pth" % cfg.tag
    if os.path.exists(ck): model.load_state_dict(torch.load(ck, map_location=dev, weights_only=True))
    model.eval()
    ev = M.evaluate(model, ds, dev); Y, P = ev["true"], ev["pred"]
    pdev = 100*(ev["peak_pred"]-ev["peak_true"])/ev["peak_true"]
    rel = globals()["rel_" + mode] / rel_obs
    row = [mode, '"%s"' % desc, "%.1f" % bucket,
           "%.4f" % ev["nse"], "%.2f" % ev["rmse"], "%.2f" % float(np.mean(np.abs(Y-P))),
           "%+.2f" % (100*(P.sum()-Y.sum())/Y.sum()), "%.4f" % ev["nse_low"], "%.4f" % ev["nse_peak"]] \
        + ["%.4f" % x for x in ev["nse_days"]] \
        + ["%.0f" % ev["peak_true"], "%.0f" % ev["peak_pred"], "%+.1f" % pdev,
           "%.2f" % rel, "%.1f" % mins]
    io.open(a.csv, "a", encoding="utf-8").write(",".join(row)+"\n")
    print("[%s] NSE %.4f | NSE_peak %.4f | NSE_low %.4f | PBIAS %+.2f%% | 洪峰 %+.1f%% | 雨量比 %.2f | %.1f min"
          % (mode, ev["nse"], ev["nse_peak"], ev["nse_low"], 100*(P.sum()-Y.sum())/Y.sum(), pdev, rel, mins), flush=True)
print("\n完成 -> %s" % a.csv, flush=True)