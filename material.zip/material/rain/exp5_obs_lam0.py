
import argparse, importlib.util, csv, os, sys, time
import numpy as np, torch

spec = importlib.util.spec_from_file_location("pinn0", "PINN-LSTM-lstm.py")   # ★ lambda=0 模块
M = importlib.util.module_from_spec(spec); sys.modules["pinn0"] = M; spec.loader.exec_module(M)

MODE = ["observed"]
def _future_bucketed_patched(self, i):
    s, p = self.seq_len, self.pred_step
    fut = self.feat_raw[i:i + p].copy()
    # observed: 不做任何分档, 保持原始实测预报期降水
    api_up = self.feat_raw[i - 1, M.I_API_UP]; api_loc = self.feat_raw[i - 1, M.I_API_LOC]
    k = 0.9
    for t in range(p):
        api_up = fut[t, M.IDX_P_UP].mean() + k * api_up
        api_loc = fut[t, M.IDX_P_LOC].mean() + k * api_loc
        fut[t, M.I_API_UP] = api_up; fut[t, M.I_API_LOC] = api_loc
    fn = self._norm(fut, self.f_min, self.f_max)
    fn[:, M.I_QOUT] = 0.0
    return fn
M.HydroDataset._future_bucketed = _future_bucketed_patched

ap = argparse.ArgumentParser()
ap.add_argument("--epochs", type=int, default=1500); ap.add_argument("--dry", action="store_true")
ap.add_argument("--csv", default="rain_observed_lam0.csv"); a = ap.parse_args()

cfg = M.Config(); cfg.epochs = a.epochs
cfg.physics_weight = 0.0                      # ★ 无物理约束
cfg.tag = "rain_observed_lam0"                # ★ 独立 tag, 不覆盖任何已有产物
cfg.print_samples = 0
dev = M.get_device(cfg)
data = M.load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
ds = M.HydroDataset(data, cfg); cfg.feat_dim = ds.feat_dim

# 实测档预报期雨量总量(与 exp4 的度量口径一致)
tot = 0.0
for i in range(ds.seq_len if hasattr(ds, "seq_len") else 1, len(data["dates"]) - cfg.pred_step):
    pass
_raw = data["features"] if isinstance(data, dict) and "features" in data else None
try:
    pcol = [c for c in getattr(M, "IDX_P_ALL", [])]
    arr = ds.feat_raw
    tot = float(arr[:, pcol].sum())
except Exception as e:
    print("  (雨量总量统计跳过: %s)" % e)
if a.dry:
    print("--dry: 仅校验, 不训练"); raise SystemExit(0)

model = M.PhysicsLSTM(cfg).to(dev)
print("\n训练中...", flush=True)
t0 = time.time(); M.train_model(model, dataset=ds, cfg=cfg, device=dev); mins = (time.time() - t0) / 60
ck = "best_model_%s.pth" % cfg.tag
ev = M.evaluate(model, ds, dev)
Y = np.asarray(ev["true"]).ravel(); P = np.asarray(ev["pred"]).ravel()
nse = float(ev.get("nse", 1 - ((Y - P) ** 2).sum() / ((Y - Y.mean()) ** 2).sum()))
row = dict(mode="observed", desc="observed precipitation + no physical constraint", lambda_=cfg.physics_weight,
           NSE=round(nse, 4), RMSE=round(float(np.sqrt(((Y - P) ** 2).mean())), 3),
           MAE=round(float(np.abs(Y - P).mean()), 3),
           PBIAS=round(100 * float((P - Y).sum() / Y.sum()), 2),
           peak_obs=int(Y.max()), peak_pred=int(P.max()),
           peak_dev_pct=round(100 * (P.max() / Y.max() - 1), 2), minutes=round(mins, 1))
new = not os.path.exists(a.csv) or True
with open(a.csv, "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.writer(fh); w.writerow(list(row.keys())); w.writerow(list(row.values()))
print("\n=== 结果(实测输入 + lambda=0)===")
for k, v in row.items(): print("   %-14s %s" % (k, v))
print("已写出 %s | 权重 %s" % (a.csv, ck))