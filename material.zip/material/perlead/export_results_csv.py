
import os, sys, importlib.util, csv
os.environ["HYDRO_NO_SHOW"] = "1"
import numpy as np, torch

spec = importlib.util.spec_from_file_location("pinn", "PINN-LSTM.py")
M = importlib.util.module_from_spec(spec); sys.modules["pinn"] = M; spec.loader.exec_module(M)
cfg = M.Config(); dev = M.get_device(cfg)
data = M.load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
ds = M.HydroDataset(data, cfg); cfg.feat_dim = ds.feat_dim
print("data: train %d / test %d" % (len(ds.X_train), len(ds.X_test)), flush=True)

SRC = [("A0", "model_lstm_lam0.pth", 0.7855, 44.08), ("A1", "best_model_abl_A1.pth", 0.7548, 45.50),
       ("A2", "best_model_abl_A2.pth", 0.7517, 42.29), ("A3", "best_model_abl_A3.pth", 0.7988, 41.04),
       ("A4", "best_model_abl_A4.pth", 0.8141, 38.92),
       ("ABC_lstm_lam0", "model_lstm_lam0.pth", 0.7855, 44.08),
       ("ABC_pinn_lam1", "i18n_backup/model_pinn_lam1.pth", 0.7988, 41.04),
       ("ABC_nosm", "model_pinn_lam1_nosm.pth", 0.8141, 38.92)]
HDR = ["tag", "NSE", "RMSE", "MAE", "PBIAS", "NSE_low", "NSE_peak", "peak_dev"] + ["D%d" % i for i in range(1, 8)]
rows_out = []
print("\n%-16s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %s" % ("tag", "NSE", "RMSE", "MAE", "PBIAS", "NSE_low", "NSE_peak", "peak_dev", "check"), flush=True)
for tag, f, eNSE, eMAE in SRC:
    if not os.path.exists(f):
        print("  %-16s [missing %s]" % (tag, f), flush=True); continue
    o = torch.load(f, map_location="cpu", weights_only=False)
    sd = o["model_state_dict"] if isinstance(o, dict) and "model_state_dict" in o else o
    mo = M.PhysicsLSTM(cfg).to(dev); mo.load_state_dict(sd); mo.eval()
    ev = M.evaluate(mo, ds, dev)
    Y, P = np.asarray(ev["true"]), np.asarray(ev["pred"])
    NSE, RMSE = ev["nse"], ev["rmse"]
    MAE = float(np.mean(np.abs(Y - P)))
    PB = 100 * float(np.sum(P - Y)) / float(np.sum(Y))
    pk = 100 * (ev["peak_pred"] / max(ev["peak_true"], 1e-9) - 1)
    ok = abs(NSE - eNSE) < 5e-4 and abs(MAE - eMAE) < 0.02
    print("%-16s %-8.4f %-8.2f %-8.2f %+7.2f%% %-8.4f %-8.4f %+7.1f%%  %s"
          % (tag, NSE, RMSE, MAE, PB, ev["nse_low"], ev["nse_peak"], pk, "OK" if ok else "** MISMATCH **"), flush=True)
    rows_out.append([tag, "%.4f" % NSE, "%.2f" % RMSE, "%.2f" % MAE, "%+.2f" % PB, "%.4f" % ev["nse_low"],
                     "%.4f" % ev["nse_peak"], "%+.1f" % pk] + ["%.4f" % v for v in ev["nse_days"]])
    if tag in ("A0", "ABC_lstm_lam0"):
        with open("results_perlead_%s.csv" % tag, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh); w.writerow(["Lead time", "NSE", "RMSE", "MAE", "PBIAS_pct"])
            for d in range(Y.shape[1]):
                y, p = Y[:, d], P[:, d]
                w.writerow(["Day %d" % (d + 1), "%.4f" % (1 - np.sum((y - p) ** 2) / np.sum((y - y.mean()) ** 2)),
                            "%.2f" % np.sqrt(np.mean((y - p) ** 2)), "%.2f" % np.mean(np.abs(y - p)),
                            "%+.2f" % (100 * np.sum(p - y) / np.sum(y))])
with open("results_ablation.csv", "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.writer(fh); w.writerow(HDR)
    for r in rows_out: w.writerow(r)
print("\nwritten: results_ablation.csv / results_perlead_A0.csv / results_perlead_ABC_lstm_lam0.csv", flush=True)