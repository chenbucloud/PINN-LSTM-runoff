
import os, sys, importlib.util
os.environ["HYDRO_NO_SHOW"] = "1"
import numpy as np, torch

TAG = "lstm_lam0"
SCRIPT = "PINN-LSTM-lstm.py"
MODEL = "model_%s.pth" % TAG

spec = importlib.util.spec_from_file_location("pinn0", SCRIPT)
M = importlib.util.module_from_spec(spec); sys.modules["pinn0"] = M; spec.loader.exec_module(M)

pkg = torch.load(MODEL, map_location="cpu", weights_only=False)
cfg = M.Config()
for k, v in pkg["config"].items():
    if hasattr(cfg, k): setattr(cfg, k, v)
print("[1] 模型 %s  tag=%s  包内 NSE=%.4f" % (MODEL, cfg.tag, pkg.get("nse", float("nan"))))
print("    feat_order = %s" % pkg.get("feat_order"))
print("    y_norm = [%s, %s]" % (pkg.get("y_min"), pkg.get("y_max")))

dev = M.get_device(cfg)
data = M.load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
ds = M.HydroDataset(data, cfg); cfg.feat_dim = ds.feat_dim
print("[2] 数据 %s | 训练 %d / 测试 %d | 测试期 %s ~ %s"
      % (cfg.file_path, len(ds.X_train), len(ds.X_test), ds.test_dates[0], ds.test_dates[-1]))

model = M.PhysicsLSTM(cfg).to(dev)
model.load_state_dict(pkg["model_state_dict"]); model.eval()
ev = M.evaluate(model, ds, dev)
print("[3] evaluate() 返回键: %s" % sorted(ev.keys()))
Y, P = np.asarray(ev["true"]), np.asarray(ev["pred"])
print("    Y%s P%s   (行=预报起点, 列=预见期 1..7)" % (Y.shape, P.shape))

rows = []
print("\n[4] Table 2 逐预im期指标")
print("    %-6s %-9s %-9s %-9s %-9s" % ("Lead", "NSE", "RMSE", "MAE", "PBIAS"))
for d in range(Y.shape[1]):
    y, p = Y[:, d], P[:, d]
    nse = 1 - np.sum((y - p) ** 2) / np.sum((y - y.mean()) ** 2)
    rmse = float(np.sqrt(np.mean((y - p) ** 2)))
    mae = float(np.mean(np.abs(y - p)))
    pb = 100 * float(np.sum(p - y)) / float(np.sum(y))
    rows.append((d + 1, nse, rmse, mae, pb))
    print("    Day %-2d %-9.4f %-9.2f %-9.2f %+8.2f %%" % (d + 1, nse, rmse, mae, pb))
print("    整体   NSE=%.4f RMSE=%.2f MAE=%.2f PBIAS=%+.2f%%"
      % (ev["nse"], ev["rmse"], 100 * float(np.sum(P - Y)) / float(np.sum(Y)) * 0 + float(np.mean(np.abs(Y - P))), 100 * float(np.sum(P - Y)) / float(np.sum(Y))))
if "--csv" in sys.argv:
    import csv
    with open("table2_perlead.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["Lead time", "NSE", "RMSE", "MAE", "PBIAS_pct"])
        for r in rows: w.writerow(["Day %d" % r[0], "%.4f" % r[1], "%.2f" % r[2], "%.2f" % r[3], "%+.2f" % r[4]])
    print("\n已写 table2_perlead.csv")