
import os, sys, importlib.util, csv
os.environ["HYDRO_NO_SHOW"] = "1"
import numpy as np, torch

f = sys.argv[1] if len(sys.argv) > 1 else "model_pinn_lam1_nosm.pth"
tag = os.path.basename(f).replace("model_", "").replace(".pth", "")
out = sys.argv[2] if len(sys.argv) > 2 else "results_perlead_%s.csv" % tag

spec = importlib.util.spec_from_file_location("pinn", "PINN-LSTM.py")
M = importlib.util.module_from_spec(spec); sys.modules["pinn"] = M; spec.loader.exec_module(M)
cfg = M.Config(); dev = M.get_device(cfg)
data = M.load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
ds = M.HydroDataset(data, cfg); cfg.feat_dim = ds.feat_dim
o = torch.load(f, map_location="cpu", weights_only=False)
sd = o["model_state_dict"] if isinstance(o, dict) and "model_state_dict" in o else o
mo = M.PhysicsLSTM(cfg).to(dev); mo.load_state_dict(sd); mo.eval()
ev = M.evaluate(mo, ds, dev)
Y, P = np.asarray(ev["true"]), np.asarray(ev["pred"])

print("\n===== %s  逐预见期结果 =====" % f)
print("  %-6s %-9s %-9s %-9s %-9s" % ("Lead", "NSE", "RMSE", "MAE", "PBIAS"))
rows = []
for d in range(Y.shape[1]):
    y, p = Y[:, d], P[:, d]
    nse = 1 - np.sum((y - p) ** 2) / np.sum((y - y.mean()) ** 2)
    rmse = float(np.sqrt(np.mean((y - p) ** 2)))
    mae = float(np.mean(np.abs(y - p)))
    pb = 100 * float(np.sum(p - y)) / float(np.sum(y))
    rows.append(("Day %d" % (d + 1), nse, rmse, mae, pb))
    print("  %-6s %-9.4f %-9.2f %-9.2f %+8.2f %%" % ("Day %d" % (d + 1), nse, rmse, mae, pb))
print("  整体   NSE=%.4f RMSE=%.2f MAE=%.2f PBIAS=%+.2f%%" % (ev["nse"], ev["rmse"], float(np.mean(np.abs(Y - P))), 100 * float(np.sum(P - Y)) / float(np.sum(Y))))
with open(out, "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.writer(fh); w.writerow(["Lead time", "NSE", "RMSE", "MAE", "PBIAS_pct"])
    for r in rows: w.writerow([r[0], "%.4f" % r[1], "%.2f" % r[2], "%.2f" % r[3], "%+.2f" % r[4]])
print("\n已写 %s" % out)