
import argparse, importlib.util, sys, io, csv, os
import numpy as np, torch

spec = importlib.util.spec_from_file_location("pinn", "PINN-LSTM.py")
M = importlib.util.module_from_spec(spec); sys.modules["pinn"] = M; spec.loader.exec_module(M)

ap = argparse.ArgumentParser()
ap.add_argument("ckpt", nargs="?", default="best_model_pinn_lam1.pth")
ap.add_argument("--out", default="diag_rc.csv")
ap.add_argument("--fig", default="fig_rc.png")
a = ap.parse_args()

cfg = M.Config(); dev = M.get_device(cfg)
data = M.load_hydro_data(cfg.file_path)
n_tr = int(len(data["Qout"]) * cfg.train_rate)
Qobs = np.asarray(data["Qout"], dtype=np.float64)
y, x1 = Qobs[1:n_tr], Qobs[0:n_tr - 1]
CLASSES = [(0, 100, "0-100"), (100, 500, "100-500"), (500, 1500, "500-1500"), (1500, 1e9, ">1500")]

def rc_table(model, label):
    P_up = torch.as_tensor(np.mean([data["P_" + s] for s in ["song", "bai", "zhang"]], axis=0),
                           dtype=torch.float32, device=dev).unsqueeze(0)
    P_loc = torch.as_tensor(np.mean([data["P_" + s] for s in ["dj", "lang", "mu"]], axis=0),
                            dtype=torch.float32, device=dev).unsqueeze(0)
    api_u = torch.as_tensor(np.asarray(data["API_up"], dtype=np.float32), device=dev).unsqueeze(0)
    api_l = torch.as_tensor(np.asarray(data["API_loc"], dtype=np.float32), device=dev).unsqueeze(0)
    with torch.no_grad():
        R_up = model.runoff_scs(P_up, api_u)
        R_loc = model.runoff_scs(P_loc, api_l)
        Qrun = (model.convolve_uh(R_up, model.get_uh(model.uh_n_up), model.area_up)
                + model.convolve_uh(R_loc, model.get_uh(model.uh_n_loc), model.area_loc)
                ).squeeze(0).cpu().numpy().astype(np.float64)[1:n_tr]
        k1 = float(model.get_k1())
        al = float(torch.nn.functional.softplus(model.alpha_run_log))
    Yimp = np.clip(y - k1 * x1, 0, None)
    rows = []
    print("\n=== %s (k1=%.4f alpha=%.4f) ===" % (label, k1, al))
    print("    %-10s %6s %11s %11s %9s" % ("class", "n", "demand", "routed", "r_c"))
    for lo, hi, nm in CLASSES:
        sel = (y >= lo) & (y < hi)
        if sel.sum() < 5:
            print("    %-10s %6d   (样本不足,跳过)" % (nm, sel.sum())); continue
        d, r = float(Yimp[sel].mean()), float(Qrun[sel].mean())
        r_c = r / (d + 1e-9)
        rows.append((nm, int(sel.sum()), d, r, r_c))
        print("    %-10s %6d %11.2f %11.2f %9.3f" % (nm, sel.sum(), d, r, r_c))
    return rows

# ---------- 状态 c: 部署模型(先测, 因为后面率定会覆盖参数) ----------
model = M.PhysicsLSTM(cfg).to(dev)
o = torch.load(a.ckpt, map_location="cpu", weights_only=False)
sd = o["model_state_dict"] if isinstance(o, dict) and "model_state_dict" in o else o
model.load_state_dict(sd); model.eval()
res = {"deployed": rc_table(model, "c) deployed model (%s)" % a.ckpt)}

# ---------- 状态 a/b: 两种率定 ----------
for key, ref, lab in [("flood", 500.0, "b) flood-weighted calibration (Q_ref=500)"),
                      ("ls", 1e9, "a) ordinary least-squares calibration")]:
    c2 = M.Config(); c2.calib_flow_weight_ref = ref; c2.freeze_physics = False
    m2 = M.PhysicsLSTM(c2).to(dev)
    M.calibrate_physics(m2, data, c2, verbose=False)
    m2.eval()
    res[key] = rc_table(m2, lab)

# ---------- CSV ----------
with io.open(a.out, "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.writer(fh); w.writerow(["state", "class", "n", "demand", "routed", "r_c"])
    for st in ["ls", "flood", "deployed"]:
        for nm, n, d, r, rc in res[st]:
            w.writerow([st, nm, n, "%.2f" % d, "%.2f" % r, "%.3f" % rc])
print("\n明细 -> %s" % a.out)

# ---------- 图 ----------
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 8, "font.family": "DejaVu Sans", "axes.linewidth": 0.8,
                     "axes.grid": True, "grid.alpha": 0.3, "grid.linewidth": 0.5, "legend.frameon": False})
lab_order = sorted({nm for st in res for nm, *_ in res[st]}, key=lambda s: [c[2] for c in CLASSES].index(s))
x = np.arange(len(lab_order)); bw = 0.26
fig, ax = plt.subplots(figsize=(3.543, 2.9), dpi=300)
trio = [("ls", "#4d4d4d", "ordinary LS"), ("flood", "#1f77b4", "flood-weighted"), ("deployed", "#d62728", "deployed (trained)")]
for i, (st, col, lb) in enumerate(trio):
    d = {nm: rc for nm, n, dm, rt, rc in res[st]}
    ax.bar(x + (i - 1) * bw, [d.get(nm, np.nan) for nm in lab_order], bw, color=col, label=lb, edgecolor="k", lw=0.5)
ax.axhline(1.0, color="k", lw=0.9, ls="--")
ax.text(len(lab_order) - 0.5, 1.03, "unity", fontsize=6, ha="right")
ax.set_xticks(x); ax.set_xticklabels(lab_order, fontsize=7)
ax.set_xlabel("discharge class (m³·s⁻¹)", fontsize=7.5); ax.set_ylabel("alignment ratio $r_c$", fontsize=7.5)
ax.legend(fontsize=6.3, ncol=3, loc="upper center")
ax.set_ylim(0, max(1.75, ax.get_ylim()[1]))
fig.tight_layout(); fig.savefig(a.fig, dpi=300); plt.close(fig)
print("图 -> %s  (%.2f cm 宽)" % (a.fig, fig.get_size_inches()[0] * 2.54))