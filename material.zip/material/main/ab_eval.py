
import importlib.util, io, os, sys
import numpy as np, torch

spec = importlib.util.spec_from_file_location("pinn", "PINN-LSTM.py")
M = importlib.util.module_from_spec(spec); sys.modules["pinn"] = M; spec.loader.exec_module(M)

RUNS = [("lstm_lam0",      "best_model_lstm_lam0.pth",      "lambda=0.0, omega_uh=2.0 (pure LSTM)"),
        ("pinn_lam1",      "best_model_pinn_lam1.pth",      "lambda=1.0, omega_uh=2.0"),
        ("pinn_lam1_nosm", "best_model_pinn_lam1_nosm.pth", "lambda=1.0, omega_uh=0.0")]
want = set(sys.argv[1:])
cfg = M.Config(); dev = M.get_device(cfg)
data = M.load_hydro_data(cfg.file_path)
ds = M.HydroDataset(data, cfg)          # 测试集与训练时完全一致
print("测试样本: %d 个起点 x %d 步 = %d 个值\n" % (len(ds.X_test), cfg.pred_step, len(ds.X_test) * cfg.pred_step))

res = {}
for name, ck, desc in RUNS:
    if want and name not in want: continue
    if not os.path.exists(ck): print("  [跳过] %s 尚未生成" % ck); continue
    model = M.PhysicsLSTM(cfg).to(dev)
    if cfg.calibrate_physics: M.calibrate_physics(model, data, cfg, verbose=False)
    model.load_state_dict(torch.load(ck, map_location=dev, weights_only=True)); model.eval()
    ev = M.evaluate(model, ds, dev); Y, P = ev["true"], ev["pred"]
    mae = float(np.mean(np.abs(Y - P)))
    pdev = 100 * (ev["peak_pred"] - ev["peak_true"]) / ev["peak_true"]
    pb = 100 * (P.sum() - Y.sum()) / Y.sum()
    res[name] = dict(desc=desc, NSE=ev["nse"], RMSE=ev["rmse"], MAE=mae, PBIAS=pb,
                     NSE_low=ev["nse_low"], NSE_peak=ev["nse_peak"],
                     D=ev["nse_days"], peak_true=ev["peak_true"], peak_pred=ev["peak_pred"], dev=pdev)
    print("  [%s] NSE=%.4f RMSE=%.2f MAE=%.2f PBIAS=%+.2f%% NSE_low=%.4f NSE_peak=%.4f 洪峰=%+.1f%%"
          % (name, ev["nse"], ev["rmse"], mae, pb, ev["nse_low"], ev["nse_peak"], pdev), flush=True)

if not res: print("\n无可用权重"); sys.exit(0)
ks = ["lstm_lam0", "pinn_lam1", "pinn_lam1_nosm"]
ks = [k for k in ks if k in res]
base = res.get("lstm_lam0")
hdr = "run,NSE,RMSE,MAE,PBIAS,NSE_low,NSE_peak,peak_true,peak_pred,peak_dev," + ",".join("D%d" % i for i in range(1, 8))
io.open("ab_compare.csv", "w", encoding="utf-8").write(hdr + "\n")
for k in ks:
    d = res[k]
    io.open("ab_compare.csv", "a", encoding="utf-8").write(
        ",".join([k] + ["%.4f" % d["NSE"], "%.2f" % d["RMSE"], "%.2f" % d["MAE"], "%+.2f" % d["PBIAS"],
                       "%.4f" % d["NSE_low"], "%.4f" % d["NSE_peak"], "%.0f" % d["peak_true"],
                       "%.0f" % d["peak_pred"], "%+.1f" % d["dev"]] + ["%.4f" % x for x in d["D"]]) + "\n")
print("\n" + "=" * 96)
print("%-16s %-8s %-8s %-8s %-8s %-9s %-9s %-9s %s" % ("run", "NSE", "RMSE", "MAE", "PBIAS", "NSE_low", "NSE_peak", "Peak dev", "dNSE"))
for k in ks:
    d = res[k]
    dl = "-" if base is None else "%+.4f" % (d["NSE"] - base["NSE"])
    print("%-16s %-8.4f %-8.2f %-8.2f %+-8.2f %-9.4f %-9.4f %+-9.1f %s" % (k, d["NSE"], d["RMSE"], d["MAE"], d["PBIAS"], d["NSE_low"], d["NSE_peak"], d["dev"], dl))
print("=" * 96)
print("\n逐天 NSE:")
print("  %-16s %s" % ("run", " ".join("D%d" % i for i in range(1, 8))))
for k in ks:
    print("  %-16s %s  衰减D1-D7=%.4f" % (k, " ".join("%.4f" % x for x in res[k]["D"]), res[k]["D"][0] - res[k]["D"][-1]))
print("\n-> ab_compare.csv")