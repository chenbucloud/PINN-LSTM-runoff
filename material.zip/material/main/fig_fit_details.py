
import os, sys, importlib.util, csv, argparse
os.environ["HYDRO_NO_SHOW"] = "1"
import numpy as np, torch

ap = argparse.ArgumentParser()
ap.add_argument("ckpt", nargs="?", default="model_pinn_lam1_nosm.pth")
ap.add_argument("--out", default="fig_fit_zoom.png")
ap.add_argument("--width", type=float, default=7.2, help="画布宽(英寸)")
a = ap.parse_args()

spec = importlib.util.spec_from_file_location("p0", "PINN-LSTM-lstm.py")
M = importlib.util.module_from_spec(spec); sys.modules["p0"] = M; spec.loader.exec_module(M)
pkg = torch.load(a.ckpt, map_location="cpu", weights_only=False)
cfg = M.Config()
for k, v in pkg["config"].items():
    if hasattr(cfg, k): setattr(cfg, k, v)
dev = M.get_device(cfg)
data = M.load_hydro_data(cfg.file_path, cfg.sheet_name, cfg.start_date, cfg.evap_valid_date)
ds = M.HydroDataset(data, cfg); cfg.feat_dim = ds.feat_dim
mo = M.PhysicsLSTM(cfg).to(dev); mo.load_state_dict(pkg["model_state_dict"]); mo.eval()
ev = M.evaluate(mo, ds, dev)
Y = np.asarray(ev["true"], dtype=float); P = np.asarray(ev["pred"], dtype=float)
if Y.ndim == 1:
    Y = Y.reshape(-1, 7); P = P.reshape(-1, 7)
n, H = Y.shape
ND = list(ev.get("nse_days", []))
print("测试 %d 样本 × %d 天 | nse_days: %s" % (n, H, ["%.4f" % v for v in ND]))
for k in range(H):
    idx = np.arange(n - k)
    print("   D%d NSE=%.4f" % (k + 1, ND[k] if k < len(ND) else float("nan")))

LEADS = (1, 3, 5, 7)
C = {1: "#1f77b4", 3: "#2ca02c", 5: "#ff7f0e", 7: "#d62728"}

def lead_xy(d, lo, hi):
    """固定预见期 d 的序列在该窗口内的 (x, y)"""
    idx = np.arange(n - (d - 1)); x = idx + d - 1
    m = (x >= lo) & (x <= hi)
    return x[m], P[idx[m], d - 1]

def lead_peaks(lo, hi):
    return [(d, float(lead_xy(d, lo, hi)[1].max())) for d in LEADS]

# 两个事件: 全局最大峰; 以及样本 ~800 附近的局部最大峰
i1 = int(np.argmax(Y[:, 0]))
w800 = np.arange(max(0, 740), min(n, 861))
i2 = int(w800[int(np.argmax(Y[w800, 0]))])
print("事件1: 样本 %d (观测 %.0f) | 事件2: 样本 %d (观测 %.0f, ~800 窗口内)" % (
    i1, Y[i1, 0], i2, Y[i2, 0]))

import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 7.5, "font.family": "DejaVu Sans", "axes.linewidth": 0.8,
                     "axes.grid": True, "grid.alpha": 0.3, "grid.linewidth": 0.5,
                     "legend.frameon": False, "legend.fontsize": 6.5})
W = a.width
fig = plt.figure(figsize=(W, W * 0.88), dpi=300)
gs = fig.add_gridspec(3, 2, height_ratios=[0.90, 1.0, 1.0], hspace=0.78, wspace=0.24)
ax0 = fig.add_subplot(gs[0, :]); ax1 = fig.add_subplot(gs[1, 0]); ax2 = fig.add_subplot(gs[1, 1])
ax3 = fig.add_subplot(gs[2, 0]); ax4 = fig.add_subplot(gs[2, 1])

# ---- (a) 全期概览 ----
x = np.arange(n)
pk1 = lead_peaks(max(0, i1 - 40), min(n - 1, i1 + 40))
ax0.plot(x, Y[:, 0], color="k", lw=0.9, label="Observed")
for d in LEADS:
    xi = np.arange(n - (d - 1)); ax0.plot(xi, P[:n - (d - 1), d - 1], color=C[d], lw=0.7, alpha=0.9,
                                          label="D%d  peak %.0f" % (d, dict(pk1)[d]))
ax0.set_ylabel("Q (m$^3$ s$^{-1}$)"); ax0.set_xlabel("test sample index")
ax0.set_ylim(0, max(Y[:, 0].max(), P.max()) * 1.12)
hs0, ls0 = ax0.get_legend_handles_labels()
ls0[-1] = ls0[-1] + "  (m$^3$ s$^{-1}$)"
ax0.legend(hs0, ls0, loc="upper center", bbox_to_anchor=(0.5, -0.34), ncol=5)
ax0.text(0.012, 0.88, "(a) overview, all %d test samples" % n, transform=ax0.transAxes, fontsize=7)

# ---- (b)(c) 事件1;  (d)(e) 事件2 ----
def event_panels(axw, axz, ic, tag, title):
    lo, hi = max(0, ic - 40), min(n - 1, ic + 40)
    xs = np.arange(lo, hi + 1)
    axw.plot(xs, Y[lo:hi + 1, 0], color="k", lw=1.5, zorder=5, label="Observed")
    for d in LEADS:
        xi, yi = lead_xy(d, lo, hi); axw.plot(xi, yi, color=C[d], lw=1.0)
    axw.set_ylabel("Q (m$^3$ s$^{-1}$)"); axw.set_xlabel("test sample index")
    axw.set_ylim(0, Y[lo:hi + 1, 0].max() * 1.28)
    axw.text(0.012, 0.90, "(%s) %s, +/-40 days" % (tag, title), transform=axw.transAxes, fontsize=7)

    lo2, hi2 = max(0, ic - 10), min(n - 1, ic + 10)
    xs2 = np.arange(lo2, hi2 + 1)
    axz.plot(xs2, Y[lo2:hi2 + 1, 0], color="k", lw=1.6, marker="o", ms=2.2, zorder=5, label="Observed")
    for d in LEADS:
        xi, yi = lead_xy(d, lo2, hi2)
        axz.plot(xi, yi, color=C[d], lw=1.1, marker="s", ms=1.8)
    axz.set_ylabel("Q (m$^3$ s$^{-1}$)"); axz.set_xlabel("test sample index")
    axz.set_ylim(0, Y[lo2:hi2 + 1, 0].max() * 1.38)
    axz.text(0.012, 0.90, "(%s) %s, +/-10 days" % (tag, title), transform=axz.transAxes, fontsize=7)
    pz = lead_peaks(lo2, hi2)
    txt = "peak: obs %.0f" % Y[lo2:hi2 + 1, 0].max()
    for d, v in pz: txt += "   D%d %.0f" % (d, v)
    axz.text(0.5, 0.965, txt, transform=axz.transAxes, ha="center", va="top", fontsize=6.2,
             color="#333333", bbox=dict(fc="white", ec="none", alpha=0.85, pad=1.5))
    return pz

pk2 = event_panels(ax1, ax2, i1, "b", "largest event")
pk3 = event_panels(ax3, ax4, i2, "d", "event near sample 800")

fig.savefig(a.out, dpi=300, bbox_inches="tight")

with open("fig_fit_zoom.csv", "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.writer(fh)
    w.writerow(["lead_day", "n", "NSE_table12_convention", "peak_ratio_pred_over_obs"])
    for k in range(H):
        idx = np.arange(n - k)
        r = float(P[idx, k].max() / (Y[idx, k].max() + 1e-9))
        w.writerow([k + 1, n - k, "%.4f" % (ND[k] if k < len(ND) else float("nan")), "%.4f" % r])
    w.writerow([])
    w.writerow(["event1_sample", i1, "obs_peak", "%.1f" % Y[i1, 0]])
    for d, v in pk2: w.writerow(["event1_D%d_peak" % d, "", "%.0f" % v])
    w.writerow(["event2_sample", i2, "obs_peak", "%.1f" % Y[i2, 0]])
    for d, v in pk3: w.writerow(["event2_D%d_peak" % d, "", "%.0f" % v])
print("fig_fit_zoom.csv")
